#ifndef OPTIMIZEPAGE_H
#define OPTIMIZEPAGE_H

#include <QWidget>
#include <QStringListModel>
#include <QTreeWidgetItem>
#include "basepage.h"

namespace Ui {
class OptimizePage;
}

class OptimizePage : public BasePage
{
    Q_OBJECT

public:
    explicit OptimizePage(QWidget *parent = 0);
    ~OptimizePage();

    void addTreeRoot(QString name, QString description);
    void addTreeChild(QTreeWidgetItem *parent,
                      QString name, QString description);

private slots:

private:
    Ui::OptimizePage *ui;
    QStringListModel mat_list;
};

#endif // OPTIMIZEPAGE_H
