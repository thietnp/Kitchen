#include "tab5/optimizepage.h"
#include "ui_optimizepage.h"
#include <QAction>
#include <QStandardItemModel>
#include <QHeaderView>

OptimizePage::OptimizePage(QWidget *parent) :
    BasePage(parent),
    ui(new Ui::OptimizePage)
{
    ui->setupUi(this);

    QStringList list;
    list.append("3/4 melamine");
    list.append("Plywood");
    list.append("PVC edging");
    mat_list.setStringList(list);
    ui->listView->setModel(&mat_list);
    ui->dateEdit->setDate(QDate::currentDate().addDays(1));

    QStandardItemModel *model = new QStandardItemModel(this);
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("X")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("Y")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("X")));
    model->setHorizontalHeaderItem(3, new QStandardItem(QString("Y")));
    ui->tableView->setModel(model);

    QStandardItem *item = new QStandardItem(QString("100"));
    model->setItem(0, 0, item);
    item = new QStandardItem(QString("200"));
    model->setItem(0, 1, item);
    item = new QStandardItem(QString("0"));
    model->setItem(0, 2, item);
    item = new QStandardItem(QString("0"));
    model->setItem(0, 3, item);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch );

    // Tree view
    ui->treeCab->setColumnCount(5);
    ui->treeCab->setHeaderLabels(QStringList() << "Type" << "#" << "" << "Sheet" << "Material");
    addTreeRoot("LOWER", "1");
    addTreeRoot("LOWER", "2");
    addTreeRoot("LOWER", "3");
    addTreeRoot("UPPER", "4");
    addTreeRoot("UPPER", "5");
    addTreeRoot("CORNER", "6");
    addTreeRoot("TALL", "7");

}

OptimizePage::~OptimizePage()
{
    delete ui;
}

void OptimizePage::addTreeRoot(QString name, QString description)
{
    QTreeWidgetItem *treeItem = new QTreeWidgetItem(ui->treeCab);

    treeItem->setText(0, name);
    treeItem->setText(1, description);
    addTreeChild(treeItem, "Part type", "GABLE");
    addTreeChild(treeItem, "Part name", "Unfinished left end");
}

void OptimizePage::addTreeChild(QTreeWidgetItem *parent,
                  QString name, QString description)
{
    QTreeWidgetItem *treeItem = new QTreeWidgetItem();

    treeItem->setText(0, name);
    treeItem->setText(1, description);
    parent->addChild(treeItem);
}
