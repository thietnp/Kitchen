#ifndef CSVFILE_H
#define CSVFILE_H

#include <QObject>
#include <QStringList>

class CsvFile : public QObject
{
    Q_OBJECT
public:
    explicit CsvFile(QObject *parent = nullptr);

    static QList<QStringList> ReadLines(QString path);

signals:

public slots:
};

#endif // CSVFILE_H
