#include "document/kitchen.h"
#include "settingmodel.h"

Kitchen::Kitchen(QObject *parent) : Document(parent)
{
    QString base = SettingModel::GetKitchensDir();
    Path =  GetNextFile(base + QDir::separator() + "kitchen.ktc");
    DeliveryDate = QDate::currentDate().addDays(1);

    //SettingModel* sm = SettingModel::GetInstance();
}

Kitchen::~Kitchen()
{

}

bool Kitchen::CreateGCode(QString path)
{
    QFile data(path);
    if(!data.open(QFile::WriteOnly |QFile::Truncate))
        return false;

    QTextStream out(&data);
    out << KJOBID << "," << JobID << LINEFEED;
    out << KCNAME << "," << CustomerName << LINEFEED;
    out << KADDR << "," << Address << LINEFEED;
    out << KDATE << "," << DeliveryDate.toString("yyyy/MM/dd") << LINEFEED;

    // TODO:
//    foreach (Cabinet* c_doc, Cabinets) {
//        out << BEGIN_CAB << c_doc->Name << ">" << LINEFEED;
//        c_doc->Serialize(out);
//        out << END_CAB << LINEFEED;
//    }

    out.flush();

    data.close();
    return true;
}

// save kitchen to file
bool Kitchen::Serialize(QXmlStreamWriter* xmlWriter)
{
    xmlWriter->writeStartElement(KITCHEN);
    // write properties
    xmlWriter->writeAttribute(KJOBID, JobID);
    xmlWriter->writeAttribute(KCNAME, CustomerName);
    xmlWriter->writeAttribute(KADDR, Address);
    xmlWriter->writeAttribute(KDATE, DeliveryDate.toString("yyyy/MM/dd"));

    foreach (Room* r, Rooms) {
        r->Serialize(xmlWriter);
    }

    // end kitchen
    xmlWriter->writeEndElement();
}

bool Kitchen::Deserialize(QXmlStreamReader* xmlReader)
{
    QXmlStreamReader::TokenType token = xmlReader->readNext();
    //Parse the XML until we reach end of it
    while(!xmlReader->atEnd() && !xmlReader->hasError())
    {
        token = xmlReader->tokenType();
        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument) {
            token = xmlReader->readNext();
            continue;
        } else if (token == QXmlStreamReader::StartElement)
        {
            QString name = xmlReader->name().toString();
            if (xmlReader->name() == KITCHEN){
                if (xmlReader->attributes().hasAttribute(KJOBID))
                    JobID = xmlReader->attributes().value(KJOBID).toString();
                if (xmlReader->attributes().hasAttribute(KCNAME))
                    CustomerName = xmlReader->attributes().value(KCNAME).toString();
                if (xmlReader->attributes().hasAttribute(KADDR))
                    Address = xmlReader->attributes().value(KADDR).toString();
                if (xmlReader->attributes().hasAttribute(KDATE))
                    DeliveryDate = QDate::fromString(xmlReader->attributes().value(KDATE).toString());

                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == ROOM) {
                Room* r = new Room(this);
                if (r->Deserialize(xmlReader))
                    Rooms.append(r);
                else
                    break;
            } else if (xmlReader->name() == "parts"){
                xmlReader->readNextStartElement();
            } else {
                xmlReader->raiseError(QString("Kitchen error unknown tag: ") + xmlReader->name().toString());
            }
        } else if (token == QXmlStreamReader::EndElement){
            if (xmlReader->name() == KITCHEN)
                break;
            xmlReader->readNextStartElement();
        } else {
            xmlReader->readNextStartElement();
        }
    }

    if(xmlReader->hasError()) {
            QMessageBox::critical(nullptr,
            "XML parse error",xmlReader->errorString(),
            QMessageBox::Ok);
            return false;
    }
    return true;
}

bool Kitchen::IsSaved()
{
    return QFile(Path).exists();
}

bool Kitchen::OpenDocument(QString path)
{
    Document::OpenDocument(path);
    Rooms.clear();
    QFile* xmlFile = new QFile(path);
    if (!xmlFile->open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(nullptr, "Load XML File Problem",
                              "Couldn't open Kitchen file",
                              QMessageBox::Ok);
        QFileInfo info(path);
        return false;
    }
    QXmlStreamReader* xmlReader = new QXmlStreamReader(xmlFile);
    Deserialize(xmlReader);


    return true;
}

bool Kitchen::NewDocument(QString path)
{
    Document::NewDocument(path);
    return true;
}

bool Kitchen::SaveDocument()
{
    Document::SaveDocument();

    QFile data(Path);
    if(data.open(QFile::WriteOnly |QFile::Truncate))
    {
        QXmlStreamWriter* xmlWriter = new QXmlStreamWriter(&data);
        xmlWriter->setAutoFormatting(true);
        xmlWriter->setAutoFormattingIndent(2);
        xmlWriter->writeStartDocument();
        Serialize(xmlWriter);
        xmlWriter->writeEndDocument();
    } else {
        return false;
    }
    data.close();

    SetModifyFlag(false);
    return true;
}

bool Kitchen::CloseDocument()
{
    return true;
}
