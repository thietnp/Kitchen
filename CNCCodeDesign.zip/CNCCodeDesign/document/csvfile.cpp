#include "document/csvfile.h"
#include <QFile>
#include <QList>
#include <QDebug>
#include <QRegExp>

CsvFile::CsvFile(QObject *parent) : QObject(parent)
{

}


QList<QStringList> CsvFile::ReadLines(QString path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << file.errorString();
        return QList<QStringList>();
    }

    QList<QStringList> lineList;
    QStringList wordList;
    while (!file.atEnd()) {
        QString line = file.readLine();
        line.remove(QRegExp("[\\n\\t\\r]"));
        QStringList strlist = line.split(',');
        lineList.append(strlist);
    }
    return lineList;
}


