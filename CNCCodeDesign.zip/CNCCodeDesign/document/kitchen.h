#ifndef KITCHEN_H
#define KITCHEN_H

#include "document.h"
#include "cabinet.h"
#include <QDate>
#include "room.h"

#define KJOBID      "job_identification"
#define KCNAME      "customer_name"
#define KADDR       "address"
#define KDATE       "delivery_date"

class Kitchen : public Document
{
    Q_OBJECT
public:
    explicit Kitchen(QObject *parent = nullptr);
    virtual ~Kitchen();

    QList<Room*> Rooms;
    QString JobID;
    QString CustomerName;
    QString Address;
    QDate   DeliveryDate;

    // methods
    bool CreateGCode(QString path);
    bool Serialize(QXmlStreamWriter* xmlWriter);
    bool Deserialize(QXmlStreamReader* xmlReader);

    bool IsSaved() override;
    bool OpenDocument(QString path) override;
    bool NewDocument(QString path) override;
    bool SaveDocument() override;
    bool CloseDocument() override;
signals:

public slots:
};

#endif // KITCHEN_H
