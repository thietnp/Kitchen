#ifndef CABINETGROUPMODEL_H
#define CABINETGROUPMODEL_H
#include "utils.h"
#include "cabinet.h"

class AppliedMaterialModel;
class Wall : public Document
{
    Q_OBJECT
public:
    explicit Wall(QObject *parent = nullptr, QString name = "");
    QString Name;
    QList<Cabinet*> Cabinets;
    QList<AppliedMaterialModel*> Materials;

    void Serialize(QXmlStreamWriter* xmlWriter);
    bool Deserialize(QXmlStreamReader* xmlReader);
    Document* Clone() override;

signals:

private slots:
};

// Material sub types
enum MAT_TYPE {
    Panel,
    Edge,
    MatTypeMax
};

class MaterialModel
{
public:
    MaterialModel();
    QString MatName;
    double thickness;
};

// Material model class
class AppliedMaterialModel
{
public:
    AppliedMaterialModel();
    AppliedMaterialModel* Clone();

    QString PartType;
    QString Code[MatTypeMax];
    QString materials[MatTypeMax];
    double thickness[MatTypeMax];
};

#endif // CABINETGROUPMODEL_H
