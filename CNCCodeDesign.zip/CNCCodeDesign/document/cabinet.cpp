#include "cabinet.h"
#include <QStringList>
#include "settingmodel.h"
#include <QFileInfo>
#include "csvfile.h"

Cabinet::Cabinet(QObject* parent) : Document(parent)
{
    Features = "XXXX";
    Height = "0";
    Depth = "0";
    Width = "0";
    QString base = SettingModel::GetCabinetsDir();
    Path = GetNextFile(base + "/cabinet.cbn");
    QFileInfo ff(Path);
    Name = ff.baseName();
    if (SettingModel::GetInstance()->cabinet_types.size() > 0)
        Type = SettingModel::GetInstance()->cabinet_types.at(0);
}

Cabinet::~Cabinet()
{

}

bool Cabinet::CreateGCode(QString path)
{
    QFile data(path);
    if(data.open(QFile::WriteOnly |QFile::Truncate))
    {
        QTextStream out(&data);
        // TODO: Serialize(out, "");
    } else {
        return false;
    }
    data.close();
    return true;
}

bool Cabinet::IsSaved()
{
    return QFile(Path).exists();
}

// save cabinet to file
bool Cabinet::Serialize(QXmlStreamWriter* xmlWriter)
{
    xmlWriter->writeStartElement(CABINET);
    xmlWriter->writeAttribute(CPOS, Position);
    xmlWriter->writeAttribute(NAME, Name);
    xmlWriter->writeAttribute(TYPE, Type);
    xmlWriter->writeAttribute(CFEATURES, Features);
    xmlWriter->writeAttribute("Height", Height);
    xmlWriter->writeAttribute("Depth", Depth);
    xmlWriter->writeAttribute("Width", Width);

    xmlWriter->writeStartElement(PARTS);
    foreach (Part* p_doc, Parts) {
        p_doc->Serialize(xmlWriter, CABINET_FILE);
    }
    xmlWriter->writeEndElement();

    // end cabinet
    xmlWriter->writeEndElement();

    return true;
}

bool Cabinet::Deserialize(QXmlStreamReader* xmlReader)
{
    QXmlStreamReader::TokenType token;
    //Parse the XML until we reach end of it
    while(!xmlReader->atEnd() && !xmlReader->hasError())
    {
        token = xmlReader->tokenType();
        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument) {
            token = xmlReader->readNext();
            continue;
        } else if (token == QXmlStreamReader::StartElement)
        {
            QString name = xmlReader->name().toString();
            if (xmlReader->name() == CABINET){
                if (xmlReader->attributes().hasAttribute(CPOS))
                    Position = xmlReader->attributes().value(CPOS).toString();
                if (xmlReader->attributes().hasAttribute(NAME))
                    Name = xmlReader->attributes().value(NAME).toString();
                if (xmlReader->attributes().hasAttribute(TYPE))
                    Type = xmlReader->attributes().value(TYPE).toString();
                if (xmlReader->attributes().hasAttribute(CFEATURES))
                    Features = xmlReader->attributes().value(CFEATURES).toString();
                if (xmlReader->attributes().hasAttribute("Height"))
                    Height = xmlReader->attributes().value("Height").toString();
                if (xmlReader->attributes().hasAttribute("Depth"))
                    Depth = xmlReader->attributes().value("Depth").toString();
                if (xmlReader->attributes().hasAttribute("Width"))
                    Width = xmlReader->attributes().value("Width").toString();
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == PART){
                Part* p = new Part(this);
                p->Deserialize(xmlReader);
                Parts.append(p);
            } else if (xmlReader->name() == PARTS){
                xmlReader->readNextStartElement();
            } else {
                xmlReader->raiseError(QString("Cabinet parser error unknown tag: ") + xmlReader->name().toString());
            }
        } else if (token == QXmlStreamReader::EndElement){
            if (xmlReader->name() == CABINET)
                break;
            xmlReader->readNextStartElement();
        } else {
            xmlReader->readNextStartElement();
        }
    }

    if(xmlReader->hasError()) {
            QMessageBox::critical(nullptr,
            "XML parse error",xmlReader->errorString(),
            QMessageBox::Ok);
            return false;
    }
    return true;
}

// Create a clone of this object
Document* Cabinet::Clone()
{
    // create a copy
    Cabinet* copy = new Cabinet(this->parent());
    copy->Path = "";    // reset path
    copy->Name = Name;
    copy->Type = Type;
    copy->Features = Features;
    copy->Height = Height;
    copy->Depth = Depth;
    copy->Width = Width;

    // clone parts
    foreach (Part* p, Parts) {
        copy->Parts.append(qobject_cast<Part*>(p->Clone()));
    }

    return copy;
}

bool Cabinet::OpenDocument(QString path)
{
    Document::OpenDocument(path);
    QFile* xmlFile = new QFile(path);
    if (!xmlFile->open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(nullptr, "Load XML File Problem",
                              "Couldn't open Cabinet file",
                              QMessageBox::Ok);
        QFileInfo info(path);
        Name = info.baseName();
        return false;
    }
    QXmlStreamReader* xmlReader = new QXmlStreamReader(xmlFile);
    Deserialize(xmlReader);
    return true;
}

bool Cabinet::NewDocument(QString path)
{
    Document::NewDocument(path);
    return true;
}

bool Cabinet::SaveDocument()
{
    // Check whether part is in cabinet
    if (Path == "")
    {
        SetModifyFlag(false);
        return true;
    }
    Document::SaveDocument();

    QFile data(Path);
    if(data.open(QFile::WriteOnly |QFile::Truncate))
    {
        QXmlStreamWriter* xmlWriter = new QXmlStreamWriter(&data);
        xmlWriter->setAutoFormatting(true);
        xmlWriter->setAutoFormattingIndent(2);
        xmlWriter->writeStartDocument();
        Serialize(xmlWriter);
        xmlWriter->writeEndDocument();
    } else {
        return false;
    }
    data.close();
    SetModifyFlag(false);
    return true;
}

bool Cabinet::CloseDocument()
{
    Document::CloseDocument();
    return true;
}
