#include "document/linedata.h"
#include <QDebug>
#include "utils.h"

LineData::LineData(QObject* parent) : QObject(parent)
{

}

LineData* LineData::Clone(QObject* parent)
{
    LineData* clone = new LineData(parent);
    clone->Boxes.append(this->Boxes);
    return clone;
}

void LineData::Serialize(QTextStream& stream, QString indent)
{
    QString data;
    for (QString txt : Boxes)
    {
        data += txt + ",";
    }
    QString line = QString("<line>%1</line>").arg(data);
    stream << indent << line << LINEFEED;
}
