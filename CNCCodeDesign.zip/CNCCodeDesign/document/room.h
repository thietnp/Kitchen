#ifndef ROOM_H
#define ROOM_H
#include "wall.h"

class Room : public Document
{
    Q_OBJECT
public:
    explicit Room(QObject* parent = nullptr, QString name = "");
    ~Room();

    QString Name;
    QList<Wall*>    Walls;
    static int roomIdx; // Room index name
    int cabNum;         // Last cabinet number index
    void Serialize(QXmlStreamWriter* xmlWriter);
    bool Deserialize(QXmlStreamReader* xmlReader);
    QString NewWallName();
    int GetNextCabNum();
};

#endif // ROOM_H
