#include "cabinetgroup.h"

CabinetGroup::CabinetGroup(QObject *parent) : Document(parent)
{
    SettingModel* sm = SettingModel::GetInstance();
    foreach (QString str, sm->part_types) {
        AppliedMaterialModel* mm = new AppliedMaterialModel();
        mm->PartType = str;
        Materials.append(mm);
    }
}

AppliedMaterialModel::AppliedMaterialModel()
{
    thickness[Panel] = 0.0;
    thickness[Edge] = 0.0;
}

AppliedMaterialModel* AppliedMaterialModel::Clone()
{
    AppliedMaterialModel* copy = new AppliedMaterialModel();
    copy->PartType = PartType;
    copy->Code[Panel] = Code[Panel];
    copy->Code[Edge] = Code[Edge];
    copy->materials[Panel] = materials[Panel];
    copy->materials[Edge] = materials[Edge];
    memcpy(&copy->thickness[0], &thickness[0], sizeof(thickness));
    return copy;
}

void CabinetGroup::Serialize(QXmlStreamWriter* xmlWriter)
{
    xmlWriter->writeStartElement(CAB_GROUP);
    foreach (Cabinet* cab, Cabinets) {
        cab->Serialize(xmlWriter);
    }
    xmlWriter->writeEndElement();
}

bool CabinetGroup::Deserialize(QXmlStreamReader* xmlReader)
{
    QXmlStreamReader::TokenType token = xmlReader->readNext();
    //Parse the XML until we reach end of it
    while(!xmlReader->atEnd() && !xmlReader->hasError())
    {
        token = xmlReader->tokenType();
        if (token == QXmlStreamReader::StartElement)
        {
            if (xmlReader->name() == CAB_GROUP)
            {
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == CABINET){
                Cabinet* cab = new Cabinet(this);
                cab->Deserialize(xmlReader);
                Cabinets.append(cab);
            } else {
                xmlReader->raiseError(QString("CabinetGroupModel error unknown tag: ") + xmlReader->name().toString());
            }
        } else if (token == QXmlStreamReader::EndElement){
            if (xmlReader->name() == CAB_GROUP)
                break;
            xmlReader->readNextStartElement();
        } else {
            xmlReader->readNextStartElement();
        }
    }

    if(xmlReader->hasError()) {
            QMessageBox::critical(nullptr,
            "XML parse error",xmlReader->errorString(),
            QMessageBox::Ok);
            return false;
    }
    return true;
}

Document* CabinetGroup::Clone()
{
    // create a copy
    CabinetGroup* copy = new CabinetGroup(this->parent());

    // Clone cabinets
    foreach (Cabinet* cab, Cabinets) {
        copy->Cabinets.append(qobject_cast<Cabinet*>(cab->Clone()));
    }

    // clone materials
    foreach (AppliedMaterialModel* mm, Materials) {
        copy->Materials.append(mm->Clone());
    }

    return copy;
}
