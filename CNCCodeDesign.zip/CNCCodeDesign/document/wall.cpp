#include "wall.h"

Wall::Wall(QObject *parent, QString name) : Document(parent), Name(name)
{
    SettingModel* sm = SettingModel::GetInstance();
    // TODO:
//    foreach (QString str, sm->part_types) {
//        AppliedMaterialModel* mm = new AppliedMaterialModel();
//        mm->PartType = str;
//        Materials.append(mm);
//    }
}

AppliedMaterialModel::AppliedMaterialModel()
{
    thickness[Panel] = 0.0;
    thickness[Edge] = 0.0;
}

AppliedMaterialModel* AppliedMaterialModel::Clone()
{
    AppliedMaterialModel* copy = new AppliedMaterialModel();
    copy->PartType = PartType;
    copy->Code[Panel] = Code[Panel];
    copy->Code[Edge] = Code[Edge];
    copy->materials[Panel] = materials[Panel];
    copy->materials[Edge] = materials[Edge];
    memcpy(&copy->thickness[0], &thickness[0], sizeof(thickness));
    return copy;
}

void Wall::Serialize(QXmlStreamWriter* xmlWriter)
{
    xmlWriter->writeStartElement(WALL);
    xmlWriter->writeAttribute(NAME, Name);
    foreach (Cabinet* cab, Cabinets) {
        cab->Serialize(xmlWriter);
    }
    xmlWriter->writeEndElement();
}

bool Wall::Deserialize(QXmlStreamReader* xmlReader)
{
    QXmlStreamReader::TokenType token;
    //Parse the XML until we reach end of it
    while(!xmlReader->atEnd() && !xmlReader->hasError())
    {
        token = xmlReader->tokenType();
        if (token == QXmlStreamReader::StartElement)
        {
            if (xmlReader->name() == WALL)
            {
                if (xmlReader->attributes().hasAttribute(NAME))
                    Name = xmlReader->attributes().value(NAME).toString();
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == CABINET){
                Cabinet* cab = new Cabinet(this);
                cab->Deserialize(xmlReader);
                Cabinets.append(cab);
            } else {
                xmlReader->raiseError(QString("Wall error unknown tag: ") + xmlReader->name().toString());
            }
        } else if (token == QXmlStreamReader::EndElement){
            if (xmlReader->name() == WALL)
                break;
            xmlReader->readNextStartElement();
        } else {
            xmlReader->readNextStartElement();
        }
    }

    if(xmlReader->hasError()) {
            QMessageBox::critical(nullptr,
            "XML parse error",xmlReader->errorString(),
            QMessageBox::Ok);
            return false;
    }
    return true;
}

Document* Wall::Clone()
{
    // create a copy
    Wall* copy = new Wall(this->parent());

    // Clone cabinets
    foreach (Cabinet* cab, Cabinets) {
        copy->Cabinets.append(qobject_cast<Cabinet*>(cab->Clone()));
    }

    // clone materials
    foreach (AppliedMaterialModel* mm, Materials) {
        copy->Materials.append(mm->Clone());
    }

    return copy;
}
