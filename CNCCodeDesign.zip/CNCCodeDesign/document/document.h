#ifndef ABSTRACTDOC_H
#define ABSTRACTDOC_H

#include <QObject>
#include <QMap>
#include <QVariant>
#include "utils.h"
#include "variableline.h"

#define PROPERTY_INVALID    "Property invalid!"

class Document : public QObject
{
    Q_OBJECT
public:
    Document(QObject* parent = nullptr);
    virtual ~Document();

    QString Path;

    //QVariant GetProperty(QString name);
    //QString GetStringProperty(QString name) { return GetProperty(name).toString();}
    inline bool IsModified() { return bModified; }
    void SetModifyFlag(bool b);
    void SetVariable(QString key, QString value);
    virtual bool IsSaved();
    bool ContainProperty(QString pro);
    QStringList GetPropertyList();

    virtual Document* Clone();
    virtual bool OpenDocument(QString path);
    virtual bool NewDocument(QString path);
    virtual bool SaveDocument();
    virtual bool CloseDocument();

public:
    // Property list
    QList<VarModel*> Properties;

protected:
    bool bModified;     // Modification flag
    uint32_t nVersion;  // Version number, format in yyMMdd

private slots:
    void on_DataChanged();
};

#endif // ABSTRACTDOC_H
