#ifndef PART_H
#define PART_H
#include "document.h"
#include <QList>
#include "operationdata.h"
#include <QXmlStreamReader>
#include <QXmlStreamWriter>

#define PNAME       "name"
#define PTYPE       "type"
#define PFEATURES   "features"

enum CNC_FILE {
    PART_FILE,
    CABINET_FILE,
    KITCHEN_FILE,
    GCODE_FILE
};

class Part : public Document
{
    Q_OBJECT
public:
    explicit Part(QObject* parent = nullptr);
    ~Part();

    QString Name;
    QString Type;
    QString Features;
    QList<OperationData*> OpeData;

    bool Serialize(QXmlStreamWriter* xmlWriter, CNC_FILE type);
    bool Deserialize(QXmlStreamReader* xmlReader);
    bool CreateGCode(QString path);

    Document* Clone() override;
    bool OpenDocument(QString path) override;
    bool NewDocument(QString path) override;
    bool SaveDocument() override;
    bool CloseDocument() override;
};

#endif // PART_H
