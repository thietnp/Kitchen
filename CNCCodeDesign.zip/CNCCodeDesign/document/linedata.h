#ifndef DOCUMENTLINEDATA_H
#define DOCUMENTLINEDATA_H

#include <QObject>
#include <QList>
#include <QTextStream>

class LineData : public QObject
{
public:
    LineData(QObject* parent = nullptr);
    QList<QString> Boxes;

    LineData* Clone(QObject* parent);
    void Serialize(QTextStream& stream, QString indent);
};

#endif // DOCUMENTLINEDATA_H
