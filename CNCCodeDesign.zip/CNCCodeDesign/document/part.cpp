#include <QFile>
#include <QDir>
#include "document/part.h"
#include "settingmodel.h"
#include <qpair.h>
#include "cabinet.h"
#include <QStringList>

extern QStringList str_Operations;
// Default variable names
QStringList def_var = {"Cabinet Height",
                             "Cabinet Depth",
                             "Cabinet Width",
                             "Material Thickness",
                             "Edging Thickness",
                             "Offset X",
                             "Offset Y"};

Part::Part(QObject* parent) : Document(parent)
{
    for (QString str : str_Operations)
    {
        OperationData* od = new OperationData(this);
        od->Name = str;
        OpeData.append(od);
    }
    Path = GetNextFile(SettingModel::GetPartsDir() + "/part.prt");
    QFileInfo ff(Path);
    Name = ff.baseName();
    Type = "";
    Features = "ABCD";

    foreach (QString var_name, SettingModel::GetInstance()->variable_list) {
        SetVariable(var_name, "0");
    }
}

Part::~Part()
{

}

// save part to file
bool Part::Serialize(QXmlStreamWriter* xmlWriter, CNC_FILE type)
{
    xmlWriter->writeStartElement(PART);
    xmlWriter->writeAttribute(PNAME, Name);
    xmlWriter->writeAttribute(PTYPE, Type);
    xmlWriter->writeAttribute(PFEATURES, Features);

    xmlWriter->writeStartElement(VARIABLES);
    foreach (VarModel* vm, Properties) {
        xmlWriter->writeEmptyElement(VARIABLE);
        xmlWriter->writeAttribute("name", vm->Name);
        xmlWriter->writeAttribute("value", vm->Value);
    }
    xmlWriter->writeEndElement();

    xmlWriter->writeStartElement(OPERATIONS);
    for (OperationData* o : OpeData)
    {
        o->Serialize(xmlWriter);
    }
    xmlWriter->writeEndElement();   // end operations

    // end part
    xmlWriter->writeEndElement();
    return true;
}

bool Part::Deserialize(QXmlStreamReader* xmlReader)
{
    OperationData* od = NULL;
    int idx = -1;   // Operation index

    // Clear variable
    Properties.clear();

    QXmlStreamReader::TokenType token;
    //Parse the XML until we reach end of it
    while(!xmlReader->atEnd() && !xmlReader->hasError())
    {
        token = xmlReader->tokenType();
        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument) {
            token = xmlReader->readNext();
            continue;
        } else if (token == QXmlStreamReader::StartElement)
        {
            QString name = xmlReader->name().toString();
            if (xmlReader->name() == PART){
                if (xmlReader->attributes().hasAttribute(PNAME))
                    Name = xmlReader->attributes().value(PNAME).toString();
                if (xmlReader->attributes().hasAttribute(PTYPE))
                    Type = xmlReader->attributes().value(PTYPE).toString();
                if (xmlReader->attributes().hasAttribute(PFEATURES))
                    Features = xmlReader->attributes().value(PFEATURES).toString();
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == VARIABLES){
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == VARIABLE){
                QString varname, value;
                if (xmlReader->attributes().hasAttribute("name"))
                     varname = xmlReader->attributes().value("name").toString();
                if (xmlReader->attributes().hasAttribute("value"))
                    value = xmlReader->attributes().value("value").toString();

                VarModel* v = new VarModel(varname, value);
                Properties.append(v);

                xmlReader->skipCurrentElement();
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == OPERATIONS){
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == OPERATION){
                idx++;
                if (idx >= OpeData.count())
                {
                    // invalid
                    continue;
                }
                od = OpeData[idx];
                while(xmlReader->readNextStartElement())
                {
                    token = xmlReader->tokenType();
                    if (token == QXmlStreamReader::StartElement &&
                            xmlReader->name() == "line")
                    {
                        LineData* ld = new LineData(od);
                        QString line = xmlReader->readElementText();
                        QStringList strlist = line.split(',');
                        if (strlist.last() == "")
                            strlist.pop_back();    // Remove last blank item
                        ld->Boxes.append(strlist);
                        od->Lines.append(ld);
                    }
                }
                xmlReader->readNextStartElement();
            } else {
                xmlReader->raiseError(QString("Part error unknown tag: ") + xmlReader->name().toString());
            }
        } else if (token == QXmlStreamReader::EndElement){
            if (xmlReader->name() == PART)
                break;
            xmlReader->readNextStartElement();
        } else {
            xmlReader->readNextStartElement();
        }
    }

    if(xmlReader->hasError()) {
            QMessageBox::critical(nullptr,
            "XML parse error",xmlReader->errorString(),
            QMessageBox::Ok);
            return false;
    }

    return true;
}

bool Part::CreateGCode(QString path)
{
    // Check whether part is in cabinet
    if (Path == "")
        return true;

    QFile data(Path);
    if(data.open(QFile::WriteOnly |QFile::Truncate))
    {
        QTextStream out(&data);
        //TODO: Serialize(out, /*GCODE_FILE*/PART_FILE, "");
    } else {
        return false;
    }
    data.close();
    return true;
}

// Create a clone of this object
Document* Part::Clone()
{
    // create a copy
    Part* copy = new Part(this->parent());
    copy->Path = "";        // reset path
    copy->Name = Name;
    copy->Type = Type;
    copy->Features = Features;
    copy->Properties.clear();

    foreach (VarModel* vm, Properties) {
        copy->SetVariable(vm->Name, vm->Value);
    }

    // clone operation data
    int i = 0;
    foreach (OperationData* od, OpeData) {
        OperationData* od2 = new OperationData(copy);
        od2->Name = od->Name;
        foreach (LineData* ld, od->Lines) {
            LineData* ld2 = ld->Clone(od2);
            od2->Lines.append(ld2);
        }
        copy->OpeData.replace(i, od2);
        i++;
    }

    return copy;
}

bool Part::OpenDocument(QString path)
{
    Document::OpenDocument(path);
    QFile* xmlFile = new QFile(path);
    if (!xmlFile->open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(nullptr, "Load XML File Problem",
                              "Couldn't open Part file",
                              QMessageBox::Ok);
        QFileInfo info(path);
        Name = info.baseName();
        return false;
    }
    QXmlStreamReader* xmlReader = new QXmlStreamReader(xmlFile);

    Deserialize(xmlReader);
    xmlFile->close();

    return true;
}

bool Part::NewDocument(QString path)
{
    return true;
}

bool Part::SaveDocument()
{
    // Check whether part is in cabinet
    if (Path == "")
    {
        SetModifyFlag(false);
        return true;
    }

    QFile data(Path);
    if(data.open(QFile::WriteOnly |QFile::Truncate))
    {
        QXmlStreamWriter* xmlWriter = new QXmlStreamWriter(&data);
        xmlWriter->setAutoFormatting(true);
        xmlWriter->setAutoFormattingIndent(2);
        xmlWriter->writeStartDocument();
        Serialize(xmlWriter, PART_FILE);
        xmlWriter->writeEndDocument();
    } else {
        return false;
    }
    data.close();
    SetModifyFlag(false);
    return true;
}

bool Part::CloseDocument()
{
    return true;
}
