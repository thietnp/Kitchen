#include "room.h"
int Room::roomIdx = 1;
Room::Room(QObject* parent, QString name) : Document(parent),
    Name(name)
{
    if (name == "")
        Name = QString("Room %1").arg(roomIdx++);
    cabNum = 1;
}

Room::~Room()
{

}

void Room::Serialize(QXmlStreamWriter* xmlWriter)
{
    xmlWriter->writeStartElement(ROOM);

    // write walls
    foreach (Wall* w, Walls) {
        w->Serialize(xmlWriter);
    }

    // end room
    xmlWriter->writeEndElement();
}

bool Room::Deserialize(QXmlStreamReader* xmlReader)
{
    QXmlStreamReader::TokenType token = xmlReader->readNext();
    //Parse the XML until we reach end of it
    while(!xmlReader->atEnd() && !xmlReader->hasError())
    {
        token = xmlReader->tokenType();
        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument) {
            token = xmlReader->readNext();
            continue;
        } else if (token == QXmlStreamReader::StartElement)
        {
            if (xmlReader->name() == ROOM)
            {
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == WALL){
                Wall* w = new Wall(this);
                w->Deserialize(xmlReader);
                Walls.append(w);
            } else {
                xmlReader->raiseError(QString("Wall error unknown tag: ") + xmlReader->name().toString());
            }
        } else if (token == QXmlStreamReader::EndElement){
            if (xmlReader->name() == KITCHEN)
                break;
            xmlReader->readNextStartElement();
        } else {
            xmlReader->readNextStartElement();
        }
    }

    if(xmlReader->hasError()) {
            QMessageBox::critical(nullptr,
            "XML parse error",xmlReader->errorString(),
            QMessageBox::Ok);
            return false;
    }
    return true;
}

// Get name for new wall
QString Room::NewWallName()
{
    QString name = "Wall ";
    for (int i = 1; i <= Walls.count() + 1; i++ )
    {
        bool found = false;
        foreach (Wall* w, Walls) {
            if (w->Name == name + QString::number(i))
            {
                found = true;
                break;
            }
        }
        if (!found)
        {
            name += QString::number(i);
            break;
        }
    }
    return name;
}

// Get next cabinet number
int Room::GetNextCabNum()
{
    return cabNum++;
}
