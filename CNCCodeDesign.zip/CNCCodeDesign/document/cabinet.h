#ifndef DOCUMENTCABINETDOC_H
#define DOCUMENTCABINETDOC_H

#include "document.h"
#include "part.h"
#include "settingmodel.h"

#define CABINET     "cabinet"
#define CPOS        "position"
#define CFEATURES   "features"
#define CHEIGHT     "Cabinet Height"
#define CDEPTH     "Cabinet Depth"
#define CWIDTH     "Cabinet Width"

class Cabinet : public Document
{
    Q_OBJECT
public:
    Cabinet(QObject* parent = nullptr);
    virtual ~Cabinet();

    QList<Part*> Parts;
    QString Position;
    QString Name;
    QString Features;
    QString Type;
    QString Height;
    QString Depth;
    QString Width;

    bool Serialize(QXmlStreamWriter* xmlWriter);
    bool Deserialize(QXmlStreamReader* xml);
    bool CreateGCode(QString path);
    bool IsSaved() override;

    Document* Clone() override;
    bool OpenDocument(QString path) override;
    bool NewDocument(QString path) override;
    bool SaveDocument() override;
    bool CloseDocument() override;

};

#endif // DOCUMENTCABINETDOC_H
