#include "document.h"
#include "mainwindow.h"

QString LINEFEED = "\r\n";

Document::Document(QObject* parent) : QObject(parent)
{
    bModified = false;
    // Document versions
    nVersion = 181110;          // 2018/11/10 use XML format
}

Document::~Document()
{

}

void Document::SetVariable(QString name, QString value)
{
    bool isExisted = false;
    // Check existing
    for (int i = 0; i < Properties.count(); i++)
    {
        if (Properties[i]->Name == name)
        {
            Properties[i]->Value = value;
            isExisted = true;
        }
    }

    if (isExisted)
        return;
    // add new pair
    VarModel* vm = new VarModel(name, value);
    Properties.append(vm);
}

void Document::SetModifyFlag(bool b)
{
    if (bModified != b)
    {
        bModified = b;
        MainWindow::g_mainWindow->UpdateTitle();
    }
}

bool Document::IsSaved()
{
    QFile f(Path);
    return f.exists();
}

bool Document::ContainProperty(QString pro)
{
    foreach (VarModel* vm, Properties) {
        if (vm->Name == pro)
            return true;
    }
    return false;
}

QStringList Document::GetPropertyList()
{
    QStringList list;
    for (int i = 0; i < Properties.count(); i++)
    {
        list.append(Properties[i]->Name);
    }
    return list;
}

// Note: don't use this function
Document* Document::Clone()
{
    return new Document();
}

bool Document::OpenDocument(QString path)
{
    Path = path;
    return true;
}

bool Document::NewDocument(QString path)
{
    Path = path;
    return true;
}

bool Document::SaveDocument()
{
    return true;
}

bool Document::CloseDocument()
{
    return true;
}

void Document::on_DataChanged()
{
    SetModifyFlag(true);
}
