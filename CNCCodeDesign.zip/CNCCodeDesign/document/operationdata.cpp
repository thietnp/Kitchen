#include "document/operationdata.h"
#include "utils.h"

OperationData::OperationData(QObject* parent) : QObject(parent)
{
}

void OperationData::Serialize(QXmlStreamWriter* xmlWriter)
{
    xmlWriter->writeStartElement("operation");
    xmlWriter->writeAttribute("Name", Name);

    for (LineData* line : Lines)
    {
        QString data;
        for (QString txt : line->Boxes)
        {
            data += txt + ",";
        }
        xmlWriter->writeTextElement("line", data);
    }
    xmlWriter->writeEndElement();
}
