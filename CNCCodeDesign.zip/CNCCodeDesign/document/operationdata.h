#ifndef OPERATIONDATA_H
#define OPERATIONDATA_H

#include <QObject>
#include <QList>
#include "linedata.h"
#include <QXmlStreamWriter>

class OperationData : public QObject
{
public:
    explicit OperationData(QObject* parent = nullptr);
    QList<LineData*> Lines;
    QString Name;

    void Serialize(QXmlStreamWriter* xmlWriter);
};

#endif // OPERATIONDATA_H
