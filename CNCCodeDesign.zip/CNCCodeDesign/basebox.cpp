#include <QFile>
#include <QApplication>
#include <QMenu>
#include <QContextMenuEvent>
#include <QKeySequence>
#include <QMimeData>
#include "basebox.h"
#include "linepanel.h"

BaseBox::BaseBox(QWidget* parent) : QLineEdit(parent)
{
    setStyleSheet("QLineEdit {\nborder-radius: 4px;"
                  "border: 1px solid #7f7f7f;"
                  "background-color:#add8e6;\n}\n"
                  "QLineEdit:focus {\nborder: 2px solid #0000ff;\n}");
    setFixedSize(WIDTH_BOX, HEIGHT_BOX);
    connect(this, SIGNAL(editingFinished()), (LinePanel*)parent, SLOT( on_textChanged()));
}

BaseBox::~BaseBox()
{

}

// Resize automatically so that fit content
void BaseBox::AutoSize()
{
    QFontMetrics fm = this->fontMetrics();
    int width_need = fm.boundingRect(text()).width() + 10;
    int width = qMax(WIDTH_BOX, width_need);
    setMinimumWidth(width);
}

void BaseBox::contextMenuEvent(QContextMenuEvent *event)
{
    //GetOpeFrame()->SetCurrentSelect(this);
    // The menu of the box
    QMenu* menu = new QMenu(this);
    menu->addAction(tr("Text Before"), (LinePanel*)parentWidget(), SLOT(on_TextBefore()));
    menu->addAction(tr("Text After"), (LinePanel*)parentWidget(), SLOT(on_TextAfter()));
    menu->addAction(tr("Number Before"), (LinePanel*)parentWidget(), SLOT(on_NumBefore()));
    menu->addAction(tr("Number After"), (LinePanel*)parentWidget(), SLOT(on_NumAfter()));
    menu->addAction(tr("Copy Content"), (LinePanel*)parentWidget(), SLOT(on_CopyContent()), QKeySequence::Copy);
    menu->addAction(tr("Paste"), (LinePanel*)parentWidget(), SLOT(on_PasteContent()), QKeySequence::Paste);
    menu->addSeparator();
    menu->addAction(tr("Delete Box"), (LinePanel*)parentWidget(), SLOT(on_DeleteBox()), QKeySequence::Delete);
    menu->exec(event->globalPos());
}

void BaseBox::dropEvent(QDropEvent *e)
{
    QLineEdit::dropEvent(e);
    emit editingFinished();
}
