#ifndef DEFINES_H
#define DEFINES_H
#define SETTING_FILE "system.xml"
#define X_BOX 180
#define Y_BOX 25
#define GAP     2
#define WIDTH_BOX 80
#define HEIGHT_BOX 24

#define FORM_HEIGH 96
#define HEADER_HEIGHT 60

#define MAXROW_VAR 5    // Max row of variables
#define COLUMN_VAR 4    // column of items variable

// XML tags
#define INDENT      "  "
#define XML_HEADER  "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

#define PART        "part"
#define VARIABLE    "variable"
#define VARIABLES   "variables"
#define OPERATION   "operation"
#define OPERATIONS  "operations"

#define PARTS       "parts"             // part list
#define CABINET     "cabinet"           // cabinet tag
#define WALL        "wall"              // group of cabinets

#define MATERIAL    "material"          // material tag
#define MATERIALS   "materials"         // material list
#define ROOM        "room"              // cabinet groups
#define KITCHEN     "kitchen"           // kitchen tag

#define NAME        "name"
#define TYPE        "type"

enum Act
{
    ADD = 0,
    DELETE,
    UPDATE,
    UPDATE_ALL
};

// Fixed styles

#endif // DEFINES_H
