#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QPushButton>
#include "partpage.h"
#include "cabinetpage.h"
#include "optimizepage.h"
#include "kitchenpage.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    static MainWindow* g_mainWindow;
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    // Init application
    void InitApp();
    void AddPage(BasePage *page, QString title);
    // Add tab page with scroll bars
    //void AddScrollPage(QWidget *page, QString title);
    void ActivePage(int idx);
    inline PartPage* GetPagePart() { return page_part;}
    void UpdateSystemSettings();

protected:
    void resizeEvent(QResizeEvent* event) override;
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::MainWindow *ui;
    QTabWidget *tabWidget;
    QPushButton* btnSetting;

    // tabs
    QList<BasePage*> pages;
    OptimizePage* page_otm;
    KitchenPage* page_ktc;
    CabinetPage* page_cab;
    PartPage* page_part;

public slots:
    void UpdateTitle();
private slots:
    void on_btnSettingClicked();
    void on_TabSelChanged(int idx);
};

#endif // MAINWINDOW_H
