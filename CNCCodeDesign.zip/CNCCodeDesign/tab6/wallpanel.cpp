#include "tab6/wallpanel.h"
#include "ui_wallpanel.h"
#include "floatdlg.h"
#include <QComboBox>
#include <QVariant>
#include "controlEx/decimalbox.h"

WallPanel::WallPanel(Wall* data,QWidget *parent) :
    doc(data),
    QFrame(parent),
    ui(new Ui::WallPanel)
{
    ui->setupUi(this);
    ui->lblName->setText(doc->Name);
    SettingModel* sm = SettingModel::GetInstance();
    //SetWidgetStyle(ui->btnAddCabinet, "red_button.qss");
    //ui->tableLeft->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    ui->tableMid->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableRight->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    // Cabinet table
    modelLeft = new QStandardItemModel(this);
    modelLeft->setHorizontalHeaderItem(WC_NAV, new QStandardItem(QString("        ")));
    modelLeft->setHorizontalHeaderItem(WC_INDEX, new QStandardItem(QString("Cabinet#")));
    modelLeft->setHorizontalHeaderItem(WC_NAME, new QStandardItem(QString("Cabinet Name")));
    modelLeft->setHorizontalHeaderItem(WC_TYPE, new QStandardItem(QString("Cabinet Type")));
    modelLeft->setHorizontalHeaderItem(WC_GROUP, new QStandardItem(QString("Group#")));
    modelLeft->setHorizontalHeaderItem(WC_HEIGHT, new QStandardItem(QString("Height")));
    modelLeft->setHorizontalHeaderItem(WC_DEPTH, new QStandardItem(QString("Depth")));
    modelLeft->setHorizontalHeaderItem(WC_WIDTH, new QStandardItem(QString("Width")));
    modelLeft->setHorizontalHeaderItem(WC_ADDED, new QStandardItem(QString("Total wall")));
//    int defw = 92;  // default column width
//    ui->tableLeft->setColumnWidth(WC_INDEX, defw);
//    ui->tableLeft->setColumnWidth(WC_NAME, defw);
//    ui->tableLeft->setColumnWidth(WC_TYPE, defw);
//    ui->tableLeft->setColumnWidth(WC_GROUP, defw);
//    ui->tableLeft->setColumnWidth(WC_HEIGHT, defw);
//    ui->tableLeft->setColumnWidth(WC_DEPTH, defw);
//    ui->tableLeft->setColumnWidth(WC_WIDTH, defw);
//    ui->tableLeft->setColumnWidth(WC_TOTAL, defw);
    ui->tableLeft->setItemDelegateForColumn(WC_HEIGHT, new DecimalBox(ui->tableLeft));
    ui->tableLeft->setItemDelegateForColumn(WC_DEPTH, new DecimalBox(ui->tableLeft));
    ui->tableLeft->setItemDelegateForColumn(WC_WIDTH, new DecimalBox(ui->tableLeft));
    ui->tableLeft->setItemDelegateForColumn(WC_ADDED, new DecimalBox(ui->tableLeft, 0, 999999.999, 3));
    ui->tableLeft->setModel(modelLeft);

    modelMid = new QStandardItemModel();
    horizontalHeader.append("Cabinet#");
    horizontalHeader.append("Cabinet Name");
    horizontalHeader.append("Cabinet Type");
    horizontalHeader.append("Group#");
    horizontalHeader.append("Height");
    horizontalHeader.append("Depth");
    horizontalHeader.append("Width");
    horizontalHeader.append("Total wall");
    modelMid->setHorizontalHeaderLabels(horizontalHeader);
    ui->tableMid->setModel(modelMid);
    modelRight = new QStandardItemModel();
    modelRight->setHorizontalHeaderLabels(horizontalHeader);
    ui->tableRight->setModel(modelRight);
    ui->tableRight->setItemDelegateForColumn(WC_HEIGHT, new DecimalBox(ui->tableRight));
    ui->tableRight->setItemDelegateForColumn(WC_DEPTH, new DecimalBox(ui->tableRight));
    ui->tableRight->setItemDelegateForColumn(WC_WIDTH, new DecimalBox(ui->tableRight));
    ui->tableRight->setItemDelegateForColumn(WC_ADDED, new DecimalBox(ui->tableRight, 0, 999999.999, 3));

    sm_view_cab = new QSignalMapper();
    connect(sm_view_cab, SIGNAL(mapped(QObject*)), SLOT(on_ViewCabinet(QObject*)));
    sm_remove_cab = new QSignalMapper();
    connect(sm_remove_cab, SIGNAL(mapped(int)), SLOT(on_RemoveCabinet(int)));

    int cnt = 0;
    foreach (Cabinet* cab, doc->Cabinets) {
        AddCabinetRow(cnt, cab);
        cnt++;
    }

    cnt = 0;
    foreach (AppliedMaterialModel* mm, doc->Materials) {
        // TODO: AddMaterialRow(cnt, mm);
        cnt++;
    }
}

WallPanel::~WallPanel()
{
    delete ui;
}

void WallPanel::AddCabinetRow(int idx, Cabinet* cab)
{
    modelLeft->setItem(idx, WC_INDEX, new QStandardItem(QString::number(idx + 1)));
    modelLeft->setItem(idx, WC_NAME, new QStandardItem(cab->Name));
    modelLeft->setItem(idx, WC_TYPE, new QStandardItem(cab->Type));
    modelLeft->setItem(idx, WC_HEIGHT, new QStandardItem(cab->Height));
    modelLeft->setItem(idx, WC_DEPTH, new QStandardItem(cab->Depth));
    modelLeft->setItem(idx, WC_WIDTH, new QStandardItem(cab->Width));

#if 0   // pending
    // Add [View Cabinet] button
    QPushButton* btnViewCab = new QPushButton();
    btnViewCab->setText("VIEW CABINET");
    ui->tblCabinet->setIndexWidget(modelCab->index(idx, 5), btnViewCab);
    connect(btnViewCab , SIGNAL(clicked()), sm_view_cab , SLOT(map()));
    sm_view_cab->setMapping(btnViewCab, cab);

    // Add [Remove] button
    QPushButton* btnRmCab = new QPushButton();
    QIcon icon;
    icon.addFile(QStringLiteral(":/res/remove.png"), QSize(), QIcon::Normal, QIcon::Off);
    btnRmCab->setIcon(icon);
    ui->tblCabinet->setIndexWidget(modelCab->index(idx, 6), btnRmCab);
    connect(btnRmCab , SIGNAL(clicked()), sm_remove_cab , SLOT(map()));
    sm_remove_cab->setMapping(btnRmCab, cab);
#endif
}

void WallPanel::UpdateData(bool save)
{

}

void WallPanel::SetBtnDelVisible(bool visible)
{
    if (visible)
        ui->btnRemoveWall->show();
    else
        ui->btnRemoveWall->hide();
}

void WallPanel::SetPosition(QString pos)
{
    QItemSelectionModel *select = ui->tableLeft->selectionModel();

    if (select->hasSelection()) //check if has selection
    {
        QModelIndex index = select->selectedIndexes().first();
        QWidget* w = ui->tableLeft->indexWidget(modelLeft->index(index.row(), 0));
        HeaderRowWall* header = qobject_cast<HeaderRowWall*>(w);
        if (header != nullptr)
        {
            header->SetPosName(pos);
        }
    } else {
        QMessageBox::warning(QApplication::activeWindow(), "Select Position", "Please select a row", QMessageBox::Ok);
    }

}

void WallPanel::on_btnAddCabinet_clicked()
{
    QString selfilter = tr("CBN (*.cbn)");
    QString fileName = QFileDialog::getOpenFileName(
            this,
            "Add Cabinet",
            SettingModel::GetCabinetsDir(),
            tr("All files (*.*);;CBN (*.cbn)" ),
            &selfilter
    );
    if (fileName.length() > 0)
    {
        Cabinet* c = new Cabinet(this);
        bool ret = c->OpenDocument(fileName);
        if (ret)
        {
            doc->Cabinets.append(c);
            AddCabinetRow(modelLeft->rowCount(), c);
        }
        else
        {
            delete c;
        }
    }
}

void WallPanel::on_ViewCabinet(QObject* o)
{
    QWidget* parentWnd = QApplication::activeWindow();
    Cabinet* cab = qobject_cast<Cabinet*>(o);
    if (cab == nullptr)
        return;
    Cabinet* clone = qobject_cast<Cabinet*>(cab->Clone());

    FloatDlg* flDlg = new FloatDlg(parentWnd);

    flDlg->SetDocument(clone, cab);
    connect(flDlg, SIGNAL(docChanged(Document*,Document*)), this, SLOT(on_DocChanged(Document*,Document*)));
    flDlg->show();
}

// Remove cabinet from kitchen
void WallPanel::on_RemoveCabinet(int idx)
{
    if (idx < 0)
        return;
    // TODO doc->Cabinets.remove;
    modelLeft->removeRow(idx);
    modelMid->removeRow(idx);
    modelRight->removeRow(idx);
    doc->SetModifyFlag(true);
}

void WallPanel::on_btnRemoveWall_clicked()
{
    emit removeWall();
}

// Receive notification from floating dialog
void WallPanel::on_DocChanged(Document* newdoc, Document* doc_org)
{
    Cabinet* old = qobject_cast<Cabinet*>(doc_org);
    if (qobject_cast<Wall*>(newdoc) != nullptr)
    {
        // Update material
        Wall* cg = qobject_cast<Wall*>(newdoc);
        doc = cg;
    } else  if (qobject_cast<Cabinet*>(newdoc) != nullptr)
    {
        // Replace cabinet
        Cabinet* newcab = qobject_cast<Cabinet*>(newdoc);
        int idx = doc->Cabinets.indexOf(old);
        if (idx < 0)
            return;
        doc->Cabinets.replace(idx, newcab);
        doc->SetModifyFlag(true);

        // Update row
        AddCabinetRow(idx, newcab);
    }
}


void WallPanel::on_btnAddLine_clicked()
{
    int idx  = modelLeft->rowCount();
    QComboBox* cb1 = new QComboBox(ui->tableLeft);
    cb1->addItem("ADD CABINET");
    cb1->addItem("DELETE CABINET");
    cb1->setMaximumWidth(88);
    QComboBox* cb2 = new QComboBox(ui->tableRight);
    cb2->addItem("ADD CABINET");
    cb2->addItem("DELETE CABINET");
    cb2->setMaximumWidth(88);
    modelLeft->setItem(idx, WC_INDEX, new QStandardItem(""));
    modelLeft->setItem(idx, WC_NAME, new QStandardItem());
    modelLeft->setItem(idx, WC_TYPE, new QStandardItem(""));
    modelLeft->setItem(idx, WC_HEIGHT, new QStandardItem("0000.000"));
    modelLeft->setItem(idx, WC_DEPTH, new QStandardItem("0000.000"));
    modelLeft->setItem(idx, WC_WIDTH, new QStandardItem("0000.000"));

    HeaderRowWall* header = new HeaderRowWall(this);
    Headers.append(header);
    ui->tableLeft->setIndexWidget(modelLeft->index(idx, 0), header);
    ui->tableLeft->setIndexWidget(modelLeft->index(idx, WC_NAME), cb1);
    ui->tableLeft->resizeColumnToContents(0);
    connect(header, SIGNAL(removeRow()), sm_remove_cab,SLOT(map()));
    sm_remove_cab->setMapping(header, idx);

    modelRight->setItem(idx, WC_INDEX - 1, new QStandardItem(""));
    modelRight->setItem(idx, WC_NAME -1 , new QStandardItem("ADD CABINET"));
    modelRight->setItem(idx, WC_TYPE - 1, new QStandardItem(""));
    modelRight->setItem(idx, WC_HEIGHT - 1, new QStandardItem("0000.000"));
    modelRight->setItem(idx, WC_DEPTH - 1, new QStandardItem("0000.000"));
    modelRight->setItem(idx, WC_WIDTH - 1, new QStandardItem("0000.000"));
    ui->tableRight->setIndexWidget(modelRight->index(idx, WC_NAME - 1), cb2);

    modelMid->appendRow(new QStandardItem());
    ui->tableMid->setSpan(idx, 0, 1, horizontalHeader.count());
    //QLinearGradient lg(0, 0, 0, 1);
    //lg.setColorAt(0, QColor::fromRgb(240, 240, 240));
    //lg.setColorAt(1, QColor::fromRgb(180, 180, 180));
    modelMid->setData(modelMid->index(idx, 0), QColor::fromRgb(200, 200, 200), Qt::BackgroundRole);
}

void WallPanel::on_tableLeft_clicked(const QModelIndex &index)
{
    emit selected();
}
