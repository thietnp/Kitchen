#ifndef KITCHENPAGE_H
#define KITCHENPAGE_H

#include <QWidget>
#include "kitchen.h"
#include "cabinet.h"
#include <QStandardItemModel>
#include <QSignalMapper>
#include "basepage.h"
#include "roompanel.h"

namespace Ui {
class KitchenPage;
}

class KitchenPage : public BasePage
{
    Q_OBJECT

public:
    explicit KitchenPage(QWidget *parent = 0);
    ~KitchenPage();
    Kitchen* GetDocument() { return doc;}
    void LoadDocument(Kitchen* kch);
    bool UpdateData(bool save) override;
    void UpdateLayout();
    void UpdateSettings() override;
    bool SaveModified();
    int AddRoom(Room* room);
    bool RemoveRoom(RoomPanel* panel);

private:
    Ui::KitchenPage *ui;
    Kitchen* doc;
    QList<RoomPanel *> roomPanels;

private slots:
    void on_OpenKitchen();
    void on_SaveKitchen();
    void on_SaveKitchenAs();
    void on_CreateGCode();
    void on_SaveAndExit();

    void on_DocChanged(Document* newdoc, Document* doc_org);
    void on_btnAddRoom_clicked();
    void on_ClickRemoveRoom();
    void on_btnMaterial_clicked();
};

#endif // KITCHENPAGE_H
