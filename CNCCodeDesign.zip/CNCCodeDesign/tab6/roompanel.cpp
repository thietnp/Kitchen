#include "tab6/roompanel.h"
#include "ui_roompanel.h"
#include <QMenu>

RoomPanel::RoomPanel(Room* room, QWidget *parent) :
    doc(room),
    QWidget(parent),
    ui(new Ui::RoomPanel)
{
    ui->setupUi(this);
    ui->lblName->setText(doc->Name);
    activedWall = nullptr;

    // Add virtual header table
    QStringList horizontalHeader;
    QStandardItemModel* model = new QStandardItemModel();
    horizontalHeader.append("Cabinet#");
    horizontalHeader.append("Cabinet Name");
    horizontalHeader.append("Cabinet Type");
    horizontalHeader.append("Group#");
    horizontalHeader.append("Height");
    horizontalHeader.append("Depth");
    horizontalHeader.append("Width");
    horizontalHeader.append("Added Cabinet\nWidth");
    model->setHorizontalHeaderLabels(horizontalHeader);
    ui->headerLeft->setModel(model);
    ui->headerLeft->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    SetWidgetStyle(ui->headerLeft, "table_style.qss");
    ui->headerRight->setModel(model);
    ui->headerRight->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    SetWidgetStyle(ui->headerRight, "table_style.qss");

    QStringList menus = { "Standard", "Tall", "Stacked", "Standard Corner", "Tall Corner", "Stacked Corner"};

    QSignalMapper* signalMapperSubmenu = new QSignalMapper();
    QMenu* menu = new QMenu();
    foreach (QString str, menus) {
        QAction* act = menu->addAction(str);
        connect(act, SIGNAL(triggered()), signalMapperSubmenu, SLOT(map()));
        signalMapperSubmenu->setMapping(act, str);
    }
    connect(signalMapperSubmenu, SIGNAL(mapped(const QString &)), SLOT(on_SelectPosition(const QString &)));
    //connect(signalMapperCabinet,  SIGNAL(mapped(int)), SLOT(on_btnAddCabinet_clicked(int)));

    ui->btnSelPos->setMenu(menu);

    foreach (Wall* w, doc->Walls) {
        AddWall(w);
    }
}

RoomPanel::~RoomPanel()
{
    delete ui;
}

void RoomPanel::UpdateData()
{
    // TODO: Update data
}

void RoomPanel::UpdateLayout()
{
    setMinimumHeight(80 + WallPanels.count() * 280);
}

void RoomPanel::AddWall(Wall* wall)
{
    WallPanel* wp = new WallPanel(wall);
    ui->wallList->addWidget(wp);
    WallPanels.append(wp);
    connect(wp, SIGNAL(selected()), this, SLOT(on_tableSelected()));
    connect(wp, SIGNAL(removeWall()), this, SLOT(on_btnRemoveWall_clicked()));
    UpdateLayout();
}

void RoomPanel::SetBtnDelVisible(bool visible)
{

}

void RoomPanel::on_SelectPosition(const QString &str)
{
    if (activedWall != nullptr)
    {
        activedWall->SetPosition(str);
    } else {
        QMessageBox::warning(QApplication::activeWindow(), "Select Position", "Please select a row", QMessageBox::Ok);
    }
}

void RoomPanel::on_btnAddWall_clicked()
{
    Wall* wall = new Wall(doc, doc->NewWallName());
    doc->Walls.append(wall);
    AddWall(wall);
}

void RoomPanel::on_btnRemoveWall_clicked()
{
    WallPanel* wp = qobject_cast<WallPanel*>(sender());
    if (wp == nullptr)
        return;
    ui->wallList->removeWidget(wp);
    WallPanels.removeAll(wp);
    wp->deleteLater();
    UpdateLayout();
}

void RoomPanel::on_btnRemoveRoom_clicked()
{
    emit removeRoom();
}

void RoomPanel::on_tableSelected()
{
    QObject* o = sender();
    WallPanel* wp = qobject_cast<WallPanel*>(o);
    if (wp != nullptr)
    {
        activedWall = wp;
    }
}
