#include "tab6/headerrowwall.h"
#include "ui_headerrowwall.h"

HeaderRowWall::HeaderRowWall(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::HeaderRowWall)
{
    ui->setupUi(this);
    ui->lineEdit->setText("Standard");
}

HeaderRowWall::~HeaderRowWall()
{
    delete ui;
}

void HeaderRowWall::SetPosName(QString pos)
{
    ui->lineEdit->setText(pos);
}

void HeaderRowWall::on_btnDelete_clicked()
{
    emit removeRow();
}
