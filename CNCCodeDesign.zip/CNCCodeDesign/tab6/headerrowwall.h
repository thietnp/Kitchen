#ifndef HEADERROWWALL_H
#define HEADERROWWALL_H

#include <QWidget>

namespace Ui {
class HeaderRowWall;
}

class HeaderRowWall : public QWidget
{
    Q_OBJECT

public:
    explicit HeaderRowWall(QWidget *parent = 0);
    ~HeaderRowWall();

    void SetPosName(QString pos);

signals:
    void removeRow();
private slots:
    void on_btnDelete_clicked();

private:
    Ui::HeaderRowWall *ui;
};

#endif // HEADERROWWALL_H
