#include "tab6/materialeditwnd.h"
#include "ui_materialeditwnd.h"
#include "utils.h"
#include "controlEx/decimalbox.h"
#include <QComboBox>

MaterialEditWnd::MaterialEditWnd(Kitchen* k, Mode _mode, QWidget *parent) :
    kit(k),
    mode(_mode),
    BasePage(parent),
    ui(new Ui::MaterialEditWnd)
{
    ui->setupUi(this);
    SetWidgetStyle(ui->tblPanel, "table_style.qss");
    SetWidgetStyle(ui->tblEdge, "table_style.qss");
    SetWidgetStyle(ui->tblApplied, "table_style.qss");

    // Material table
    panelMat = new QStandardItemModel(this);
    panelMat->setHorizontalHeaderItem(0, new QStandardItem(QString("   ")));
    panelMat->setHorizontalHeaderItem(1, new QStandardItem(QString("Material Name")));
    panelMat->setHorizontalHeaderItem(2, new QStandardItem(QString("Thickness")));
    ui->tblPanel->setItemDelegateForColumn(2, new DecimalBox(ui->tblPanel));
    ui->tblPanel->setModel(panelMat);

    edgeMat = new QStandardItemModel(this);
    edgeMat->setHorizontalHeaderItem(0, new QStandardItem(QString("   ")));
    edgeMat->setHorizontalHeaderItem(1, new QStandardItem(QString("Material Name")));
    edgeMat->setHorizontalHeaderItem(2, new QStandardItem(QString("Thickness")));
    ui->tblEdge->setItemDelegateForColumn(2, new DecimalBox(ui->tblEdge));
    ui->tblEdge->setModel(edgeMat);

    // Applied material table
    appliedMat = new QStandardItemModel(this);
    appliedMat->setHorizontalHeaderItem(0, new QStandardItem(QString("Part Type")));
    appliedMat->setHorizontalHeaderItem(1, new QStandardItem(QString("Material Name")));
    appliedMat->setHorizontalHeaderItem(2, new QStandardItem(QString("Panel/\nEdge")));
    appliedMat->setHorizontalHeaderItem(3, new QStandardItem(QString("Code")));
    appliedMat->setHorizontalHeaderItem(4, new QStandardItem(QString("Thickness")));
    ui->tblApplied->setModel(appliedMat);
    ui->tblApplied->setItemDelegateForColumn(4, new DecimalBox(ui->tblApplied));
    ui->tblApplied->horizontalHeader()->setResizeContentsPrecision(5);
    ui->tblApplied->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    ui->tblApplied->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);

    QStringList list;
    // Get all Part types
    foreach (Room* r, kit->Rooms) {
        foreach (Wall* w, r->Walls) {
            foreach (Cabinet* c, w->Cabinets) {
                foreach (Part* p, c->Parts) {
                    list.append(p->Type);
                }
            }
        }
    }

    list.removeDuplicates();
    int i = 0;
    foreach (QString str, list) {
        AppliedMaterialModel* mm = new AppliedMaterialModel();
        mm->PartType = str;
        AddAppliedMaterialRow(i, mm);
        i++;
    }
}

MaterialEditWnd::~MaterialEditWnd()
{
    delete ui;
}

void MaterialEditWnd::AddPanelMaterial(int idx, MaterialModel* mat)
{

}

void MaterialEditWnd::AddEdgeMaterial(int idx, MaterialModel* mat)
{

}

void MaterialEditWnd::AddAppliedMaterialRow(int idx, AppliedMaterialModel* mat)
{
    QStandardItem* ptype = new QStandardItem(mat->PartType);        // Part type
    QStandardItem* panel = new QStandardItem("Panel");
    QStandardItem* edge = new QStandardItem("Edge");
    QComboBox* mtypes1 = new QComboBox();       // Material types
    QComboBox* mtypes2 = new QComboBox();       // Material types

    SettingModel* sm = SettingModel::GetInstance();
    // TODO:
//    foreach (QString str, sm->material_list)
//    {
//        mtypes1->addItem(str);
//        mtypes2->addItem(str);
//    }

    ptype->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
    panel->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
    edge->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);

    appliedMat->setItem(idx*2, 2, panel);
    appliedMat->setItem(idx*2 + 1, 2, edge);
    ui->tblApplied->setSpan(idx*2, 0, 2, 1);
    appliedMat->setItem(idx*2, 0, ptype);
    //ui->tblApplied->setItem(appliedMat->index(idx*2, 0), ptypes);
    ui->tblApplied->setIndexWidget(appliedMat->index(idx*2, 1), mtypes1);
    ui->tblApplied->setIndexWidget(appliedMat->index(idx*2 + 1, 1), mtypes2);
}

bool MaterialEditWnd::UpdateData(bool save)
{
    return true;
}

void MaterialEditWnd::on_btnSave_clicked()
{
    UpdateData(true);
    emit saveDoc(kit);
}
