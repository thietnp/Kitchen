#ifndef ROOMPANEL_H
#define ROOMPANEL_H

#include <QWidget>
#include "room.h"
#include <QStandardItemModel>
#include <QSignalMapper>
#include "wallpanel.h"

namespace Ui {
class RoomPanel;
}

class RoomPanel : public QWidget
{
    Q_OBJECT

public:
    explicit RoomPanel(Room* room, QWidget *parent = 0);
    ~RoomPanel();

    Room* doc;
    QList<WallPanel*> WallPanels;
    //QStandardItemModel *modelWall;       // data model of walls
    QSignalMapper* signalMapperCabinet = new QSignalMapper();

    void UpdateData();
    void UpdateLayout();
    void AddWall(Wall* wall);
    void SetBtnDelVisible(bool visible);
private:
    Ui::RoomPanel *ui;
    WallPanel* activedWall;

signals:
    void removeRoom();
private slots:
    void on_SelectPosition(const QString &);
    void on_btnAddWall_clicked();
    void on_btnRemoveWall_clicked();
    void on_btnRemoveRoom_clicked();
    void on_tableSelected();
};

#endif // ROOMPANEL_H
