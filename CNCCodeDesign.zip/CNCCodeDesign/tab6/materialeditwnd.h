#ifndef MATERIALEDITWND_H
#define MATERIALEDITWND_H

#include <QWidget>
#include <QStandardItemModel>
#include "kitchen.h"
#include "basepage.h"

namespace Ui {
class MaterialEditWnd;
}

class MaterialEditWnd : public BasePage
{
    Q_OBJECT

public:
    explicit MaterialEditWnd(Kitchen* k, Mode _mode, QWidget *parent = 0);
    ~MaterialEditWnd();

    Kitchen* kit;                   // Cabinet group data
    QStandardItemModel *panelMat;           // data model of panel materials
    QStandardItemModel *edgeMat;            // data model of edge materials
    QStandardItemModel *appliedMat;         // data model of applied materials

    void AddPanelMaterial(int idx, MaterialModel* mat);
    void AddEdgeMaterial(int idx, MaterialModel* mat);
    void AddAppliedMaterialRow(int idx, AppliedMaterialModel* mat);
    bool UpdateData(bool save) override;

signals:
    void saveDoc(Document*);

private slots:
    void on_btnSave_clicked();

private:
    Ui::MaterialEditWnd *ui;
    Mode mode;

};

#endif // MATERIALEDITWND_H
