#include <QTableWidget>
#include <QTableView>
#include <QStandardItem>
#include <QMenu>
#include <QFileDialog>
#include <QMessageBox>
#include <QDesktopWidget>
#include <QShortcut>
#include "floatdlg.h"
#include "tab6/kitchenpage.h"
#include "ui_kitchenpage.h"
#include "utils.h"
#include "cabinetpage.h"
#include "mainwindow.h"

KitchenPage::KitchenPage(QWidget *parent) :
    BasePage(parent),
    ui(new Ui::KitchenPage)
{
    ui->setupUi(this);
    SetWidgetStyle(ui->headerArea, SystemStyle);

    QMenu* pmenu = new QMenu();
    pmenu->addAction(tr("Open Kitchen"), this, SLOT(on_OpenKitchen()));
    pmenu->addAction(tr("Save Kitchen"), this, SLOT(on_SaveKitchen()));
    pmenu->addAction(tr("Save Kitchen As"), this, SLOT(on_SaveKitchenAs()));
    pmenu->addAction(tr("Create G-Code"), this, SLOT(on_CreateGCode()));
    pmenu->addAction(tr("Save And Edit"), this, SLOT(on_SaveAndExit()));
    ui->btnKitchen->setMenu(pmenu);

    QShortcut *open = new QShortcut(QKeySequence("Ctrl+O"), this);
    connect(open, SIGNAL(activated()), this, SLOT(on_OpenKitchen()));
    QShortcut *save = new QShortcut(QKeySequence("Ctrl+S"), this);
    connect(save, SIGNAL(activated()), this, SLOT(on_SaveKitchen()));
    QShortcut *saveas = new QShortcut(QKeySequence("Ctrl+Alt+S"), this);
    connect(saveas, SIGNAL(activated()), this, SLOT(on_SaveKitchenAs()));
    QShortcut *gcode = new QShortcut(QKeySequence("Ctrl+G"), this);
    connect(gcode, SIGNAL(activated()), this, SLOT(on_CreateGCode()));
    QShortcut *savequit = new QShortcut(QKeySequence("Ctrl+Q"), this);
    connect(savequit, SIGNAL(activated()), this, SLOT(on_SaveAndExit()));

    doc = nullptr;
}

KitchenPage::~KitchenPage()
{
    delete ui;
}

void KitchenPage::LoadDocument(Kitchen* kch)
{
    if (doc != NULL)
    {
        while (roomPanels.count() > 0) {
            RemoveRoom(roomPanels.at(0));
        }
        delete doc;
    }
    doc = kch;

    UpdateData(false);
    if (doc->Rooms.count() == 0)
    {
        Room* r = new Room(doc);
        doc->Rooms.append(r);
        AddRoom(r);
    } else  {
        foreach (Room* r, doc->Rooms) {
            AddRoom(r);
        }
    }

    emit updateTitle();
}

bool KitchenPage::UpdateData(bool save)
{
    if (save)
    {
        QString oldjob = doc->JobID;
        QString oldname = doc->CustomerName;
        QString oldaddr = doc->Address;
        QDate olddate = doc->DeliveryDate;

        doc->JobID = ui->editJob->text();
        doc->CustomerName = ui->editCName->text();
        doc->Address = ui->editAddr->text();
        doc->DeliveryDate = ui->dateEdit->date();

        if (oldjob != doc->JobID ||
                oldname != doc->CustomerName ||
                oldaddr != doc->Address ||
                olddate != doc->DeliveryDate)
            doc->SetModifyFlag(true);
    } else {
        ui->editJob->setText(doc->JobID);
        ui->editCName->setText(doc->CustomerName);
        ui->editAddr->setText(doc->Address);
        ui->dateEdit->setDate(doc->DeliveryDate);
    }
    return true;
}

void KitchenPage::UpdateLayout()
{

}

void KitchenPage::UpdateSettings()
{

}

// return   true: save document
//          false: cancel
bool KitchenPage::SaveModified()
{
    // Check change
    UpdateData(true);
    if (doc->IsModified())
    {
        QMessageBox::StandardButton reply = QMessageBox::question(NULL, "Confirm", "The kitchen document has been modified. Do you want to save?",
                        QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        if (reply == QMessageBox::Yes)
        {
            // Save document
            doc->SaveDocument();
        } else if (reply == QMessageBox::Cancel) {
            return false;
        }
    }
    return true;
}

int KitchenPage::AddRoom(Room* room)
{
    RoomPanel* panel = new RoomPanel(room, this);
    roomPanels.append(panel);
    ui->verticalLayout_3->addWidget(panel);

    connect(panel, SIGNAL(removeRoom()), this, SLOT(on_ClickRemoveRoom()));

    if (roomPanels.count() == 1)
    {
        roomPanels[0]->SetBtnDelVisible(false);
    } else {
        roomPanels[0]->SetBtnDelVisible(true);
    }
}

bool KitchenPage::RemoveRoom(RoomPanel* panel)
{
    roomPanels.removeAll(panel);
    doc->Rooms.removeAll(panel->doc);
    delete panel->doc;
    panel->deleteLater();

    if (roomPanels.count() == 1)
    {
        roomPanels[0]->SetBtnDelVisible(false);
    } else if (roomPanels.count() > 1) {
        roomPanels[0]->SetBtnDelVisible(true);
    }
    return true;
}

void KitchenPage::on_OpenKitchen()
{
    // Open new part
    QString selfilter = tr("KTC (*.ktc)");
    QString fileName = QFileDialog::getOpenFileName(
            this,
            "Open Kitchen",
            doc->Path,
            tr("All files (*.*);;KTC (*.ktc)" ),
            &selfilter
    );
    if (fileName.length() > 0)
    {
        Kitchen* newkit = new Kitchen();
        newkit->OpenDocument(fileName);
        LoadDocument(newkit);
    }
    else
        return;
}

void KitchenPage::on_SaveKitchen()
{
    bool saved = doc->IsSaved();
    if (!doc->IsSaved())
    {
        QString selfilter = tr("KTC (*.ktc)");
        QString fileName = QFileDialog::getSaveFileName(
                this,
                "Save Kitchen",
                doc->Path,
                tr("All files (*.*);;KTC (*.ktc)" ),
                &selfilter
        );
        if (fileName.length() > 0)
        {
            doc->Path = fileName;
        }
        else
            return;
    }

    UpdateData(true);
    doc->SaveDocument();
    if (!saved)
        QMessageBox::information(QApplication::activeWindow(), "Saved", "The kitchen is created", QMessageBox::Ok);
}

void KitchenPage::on_SaveKitchenAs()
{
    QString selfilter = tr("KTC (*.ktc)");
    QString newfile = GetNextFile(SettingModel::GetKitchensDir() + "/kitchen.ktc");
    QString fileName = QFileDialog::getSaveFileName(
            this,
            "Save Kitchen",
            newfile,
            tr("All files (*.*);;KTC (*.ktc)" ),
            &selfilter
    );
    if (fileName.length() > 0)
    {
        doc->Path = fileName;
    } else
        return;

    UpdateData(true);
    doc->SaveDocument();
    QMessageBox::information(QApplication::activeWindow(), "Saved", "The kitchen is created", QMessageBox::Ok);
}

void KitchenPage::on_CreateGCode()
{
    doc->SaveDocument();
    QString selfilter = tr("TXT (*.txt)");
    QString newfile = GetNextFile(SettingModel::GetKitchensDir() + "/gcode.txt");
    QString fileName = QFileDialog::getSaveFileName(
            this,
            "Save G-Code",
            newfile,
            tr("All files (*.*);;TXT (*.txt)" ),
            &selfilter
    );
    if (fileName.length() == 0)
        return;
    doc->CreateGCode(fileName);
}

void KitchenPage::on_SaveAndExit()
{

}

void KitchenPage::on_DocChanged(Document* newdoc, Document* doc_org)
{
    Cabinet* old = qobject_cast<Cabinet*>(doc_org);
    Cabinet* newcab = qobject_cast<Cabinet*>(newdoc);

    // Replace part
    // TODO:
//    int idx = doc->Cabinets.indexOf(old);
//    doc->Cabinets.replace(idx, newcab);
//    doc->SetModifyFlag(true);

//    //model->removeRows(idx, 1);
//    AddRow(idx, newcab);
}

void KitchenPage::on_btnAddRoom_clicked()
{
    Room* r = new Room(doc);
    doc->Rooms.append(r);
    AddRoom(r);
}

void KitchenPage::on_ClickRemoveRoom()
{
    QObject* o = sender();
    RoomPanel* panel = qobject_cast<RoomPanel*>(o);
    if (panel == nullptr)
        return;
    RemoveRoom(panel);
}

void KitchenPage::on_btnMaterial_clicked()
{
    QWidget* parentWnd = QApplication::activeWindow();

    FloatDlg* flDlg = new FloatDlg(parentWnd);

    flDlg->SetDocument(doc, doc);
    SetWidgetStyle(flDlg, "label_style1.qss");
    connect(flDlg, SIGNAL(docChanged(Document*, Document*)), this, SLOT(on_DocChanged(Document*, Document*)));
    flDlg->exec();
}
