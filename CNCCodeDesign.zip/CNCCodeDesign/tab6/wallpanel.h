#ifndef CABINETGROUPPANEL_H
#define CABINETGROUPPANEL_H

#include <QFrame>
#include <QStandardItemModel>
#include <QSignalMapper>
#include "wall.h"
#include "headerrowwall.h"

namespace Ui {
class WallPanel;
}

// Wall column index
enum W_COLUMN {
    WC_NAV, // navigation column
    WC_INDEX,
    WC_NAME,
    WC_TYPE,
    WC_GROUP,
    WC_HEIGHT,
    WC_DEPTH,
    WC_WIDTH,
    WC_ADDED,
    WC_MAX
};

class WallPanel : public QFrame
{
    Q_OBJECT

public:
    explicit WallPanel(Wall* data, QWidget *parent = 0);
    ~WallPanel();
    Wall* doc;           // Cabinet group data

    void AddCabinetRow(int idx, Cabinet* cab);
    //void AddMaterialRow(int idx, MaterialModel* mat);
    void UpdateData(bool save);
    void SetBtnDelVisible(bool visible);
    void SetPosition(QString pos);

signals:
    void removeWall();
    void selected();
private:
    Ui::WallPanel *ui;

    QStandardItemModel *modelLeft;          // data model of cabinets in the left table
    QStandardItemModel* modelMid;           // middle table
    QStandardItemModel *modelRight;         // data model of cabinets in the right table
    QList<HeaderRowWall*> Headers;
    QSignalMapper* sm_view_cab;
    QSignalMapper* sm_remove_cab;
    QStringList horizontalHeader;

private slots:
    void on_btnAddCabinet_clicked();
    void on_ViewCabinet(QObject* o);
    void on_RemoveCabinet(int idx);
    void on_btnRemoveWall_clicked();
    void on_DocChanged(Document* newdoc, Document* doc_org);
    void on_btnAddLine_clicked();
    void on_tableLeft_clicked(const QModelIndex &index);
};

#endif // CABINETGROUPPANEL_H
