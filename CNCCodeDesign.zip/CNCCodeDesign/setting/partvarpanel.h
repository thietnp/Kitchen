#ifndef PARTTYPEVARFORM_H
#define PARTTYPEVARFORM_H

#include <QFrame>
#include <QStandardItemModel>
#include "settingmodel.h"

namespace Ui {
class PartVarPanel;
}

class PartVarPanel : public QFrame
{
    Q_OBJECT

public:
    explicit PartVarPanel(PartVariable* var, QWidget *parent = 0);
    ~PartVarPanel();
    QStandardItemModel* model;
    PartVariable* pv;
    static PartVarPanel* activedPanel;
    QModelIndex activeIndex;

    void AppendRow(CodePair* code);
    void SetActive(bool isActive);
protected:
    void mousePressEvent(QMouseEvent *event) override;
private slots:
    void on_btnAdd_clicked();
    void on_tableView_pressed(const QModelIndex &index);
    void on_tableView_doubleClicked(const QModelIndex &index);
    void on_selectNewCode(int n);

private:
    Ui::PartVarPanel *ui;
};

#endif // PARTTYPEVARFORM_H
