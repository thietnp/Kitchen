#ifndef SETTINGWINDOW_H
#define SETTINGWINDOW_H

#include <QDialog>
#include <QStringListModel>
#include <QStandardItemModel>
#include "part.h"
#include "partvarpanel.h"

namespace Ui {
class SettingWindow;
}
typedef enum {
    SW_MODE_SELECT = 0,
    WS_MODE_EDIT
} SW_MODE;

class SettingWindow : public QDialog
{
    Q_OBJECT

public:

    SW_MODE mode;
    explicit SettingWindow(SW_MODE _mode, QWidget *parent = 0);
    ~SettingWindow();

    // Setting window mode


    QList<PartVarPanel*> PartVarList;
    QStandardItemModel* tblheader;

    void LoadPartVariables();
    void SavePartVariables();
    static int GenStartCode();

private slots:
    void on_btnAddPart_clicked();
    void on_btnRemovePart_clicked();
    void on_btnAddCab_clicked();
    void on_btnRemoveCab_clicked();
    void on_btnAddVar_clicked();
    void on_btnRemoveVar_clicked();
    void on_btnSave_clicked();
    void on_btnCancel_clicked();

private:
    Ui::SettingWindow *ui;
    QStringListModel cabinet_type_model;
    QStringListModel variable_list_model;
};

#endif // SETTINGWINDOW_H
