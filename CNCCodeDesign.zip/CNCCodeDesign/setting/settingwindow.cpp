#include <QFile>

#include "settingwindow.h"
#include "ui_settingwindow.h"
#include "utils.h"
#include "defines.h"
#include "settingmodel.h"
#include "part.h"
#include "mainwindow.h"
extern QStringList def_var;
SettingWindow::SettingWindow(SW_MODE _mode, QWidget *parent) :
    mode(_mode),
    QDialog(parent),
    ui(new Ui::SettingWindow)
{
    ui->setupUi(this);
    if (mode == SW_MODE_SELECT)
    {
        ui->btnAddPart->setHidden(true);
        ui->btnRemovePart->setHidden(true);
        ui->label_4->setHidden(true);
        ui->variable_list->setHidden(true);
        ui->btnAddVar->setHidden(true);
        ui->btnRemoveVar->setHidden(true);
        ui->label_2->setHidden(true);
        ui->cabinet_types->setHidden(true);
        ui->btnAddCab->setHidden(true);
        ui->btnRemoveCab->setHidden(true);
    }
    SettingModel* sm = SettingModel::GetInstance();
    sm->part_vars_bk.clear();
    sm->part_vars_bk.append(sm->part_vars);
    cabinet_type_model.setStringList(sm->cabinet_types);
    variable_list_model.setStringList(sm->variable_list);

    //ui->part_types->setModel(&part_type_model);

    if (mode != SW_MODE_SELECT)
    {
        ui->cabinet_types->setModel(&cabinet_type_model);
        ui->variable_list->setModel(&variable_list_model);
    }
    SetWidgetStyle(this, ":/res/listview.qss");
    setStyleSheet("QFrame#PartVarPanel { background-color: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 1, stop: 0 #9dd, stop: 0.8 #dee)}");

    // create header table
    tblheader = new QStandardItemModel(this);
    tblheader->setHorizontalHeaderItem(0, new QStandardItem(QString("PART TYPE")));
    tblheader->setHorizontalHeaderItem(1, new QStandardItem(QString("PANEL/EDGE")));
    tblheader->setHorizontalHeaderItem(2, new QStandardItem(QString("CODE")));
    ui->tblHeader->setModel(tblheader);
    SetWidgetStyle(ui->tblHeader, "table_style.qss");

    LoadPartVariables();
}

SettingWindow::~SettingWindow()
{
    delete ui;
}

void SettingWindow::LoadPartVariables()
{
    SettingModel* sm = SettingModel::GetInstance();
    foreach (PartVariable* pv, sm->part_vars) {
        PartVarPanel* pvp = new PartVarPanel(pv);
        ui->verticalLayout_4->addWidget(pvp);
        PartVarList.append(pvp);
    }
}

void SettingWindow::SavePartVariables()
{

}

int SettingWindow::GenStartCode()
{
    int newcode = 10;
    SettingModel* sm = SettingModel::GetInstance();
    for (int i = 10; i < 99; i++)
    {
        bool found = false;
        // Looking for material code
        foreach (PartVariable* pv, sm->part_vars) {
            if (pv->nCode == i)
            {
                found = true;
                break;
            }
        }

        if (!found)
        {
            newcode = i;
            break;
        }
    }
    return newcode;
}

void SettingWindow::on_btnAddPart_clicked()
{
    SettingModel* sm = SettingModel::GetInstance();
    PartVariable* pv = new PartVariable();
    PartVarPanel* pvp = new PartVarPanel(pv);
    // get current selected panel
    int idx = PartVarList.indexOf(PartVarPanel::activedPanel);
    // append at the end if no active panel
    if (idx < 0)
        idx = PartVarList.count();
    else
        idx++;
    ui->verticalLayout_4->insertWidget(idx, pvp);
    sm->part_vars.insert(idx, pv);
    PartVarList.insert(idx, pvp);
}

void SettingWindow::on_btnRemovePart_clicked()
{
    SettingModel* sm = SettingModel::GetInstance();
    foreach (PartVarPanel* pvp, PartVarList)
    {
        if (pvp == PartVarPanel::activedPanel)
        {
            int pos = PartVarList.indexOf(pvp);
            if (pos < 0)
            {
                QMessageBox::warning(QApplication::activeWindow(), "Remove Part Variable", "Please select a Part Variable", QMessageBox::Ok);
                return;
            }
            sm->part_vars.removeAt(pos);
            PartVarList.removeAt(pos);
            ui->verticalLayout_4->removeWidget(pvp);
            pvp->deleteLater();
            PartVarPanel::activedPanel = nullptr;
            break;
        }
    }
}

void SettingWindow::on_btnAddCab_clicked()
{
    int row = ui->cabinet_types->currentIndex().row();
    if (row == -1)
        row = cabinet_type_model.rowCount();
    else
        row++;
    cabinet_type_model.insertRow(row);

    QModelIndex index = cabinet_type_model.index(row);
    ui->cabinet_types->setCurrentIndex(index);
    ui->cabinet_types->edit(index);
}

void SettingWindow::on_btnRemoveCab_clicked()
{
    QModelIndexList selectedIndexes(ui->cabinet_types->selectionModel()->selectedIndexes());

    for (QModelIndexList::const_iterator it = selectedIndexes.constEnd() - 1;
            it >= selectedIndexes.constBegin(); --it) {
        cabinet_type_model.removeRow(it->row());
    }
}

void SettingWindow::on_btnAddVar_clicked()
{
    int row = ui->variable_list->currentIndex().row();
    if (row == -1)
        row = variable_list_model.rowCount();
    else
        row++;
    variable_list_model.insertRow(row);

    QModelIndex index = variable_list_model.index(row);
    ui->variable_list->setCurrentIndex(index);
    ui->variable_list->edit(index);
}

void SettingWindow::on_btnRemoveVar_clicked()
{
    QModelIndexList selectedIndexes(ui->variable_list->selectionModel()->selectedIndexes());

    for (QModelIndexList::const_iterator it = selectedIndexes.constEnd() - 1;
            it >= selectedIndexes.constBegin(); --it) {
        variable_list_model.removeRow(it->row());
    }
}

// Click button [Save]
void SettingWindow::on_btnSave_clicked()
{
    SettingModel* sm = SettingModel::GetInstance();
    sm->cabinet_types = cabinet_type_model.stringList();
    sm->variable_list = variable_list_model.stringList();
    foreach (PartVarPanel* pvp, PartVarList) {
        pvp->pv->PartType = pvp->model->data(pvp->model->index(0, 0)).toString();
    }
    sm->SaveSettings();
    done(Accepted);
}

// Click button [Cancel]
void SettingWindow::on_btnCancel_clicked()
{
    SettingModel* sm = SettingModel::GetInstance();
    sm->part_vars = sm->part_vars_bk;
    done(Rejected);
}
