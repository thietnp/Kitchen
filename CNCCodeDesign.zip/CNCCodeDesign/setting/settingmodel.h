#ifndef SETTINGMODEL_H
#define SETTINGMODEL_H
#include <QStringList>
#include <QDir>
#include <QXmlStreamWriter>

class PartVariable;
typedef struct {
    QString pe;     // Panel/Edge
    QString Code;
} CodePair;

class SettingModel
{
    // Singleton partern
private:
    SettingModel();
    static SettingModel* instance;
public:
    static SettingModel* GetInstance()
    {
        if (instance == NULL)
        {
            instance = new SettingModel();
        }
        return instance;
    }

public:
    static QString ProjectDir;      // Project directory
    static QString GetKitchensDir() { return ProjectDir + QDir::separator() + "kitchens"; }
    static QString GetCabinetsDir() { return ProjectDir + QDir::separator() + "cabinets"; }
    static QString GetPartsDir() { return ProjectDir + QDir::separator() + "parts"; }

    // Properties
    QList<PartVariable*> part_vars;     // list of the part variables
    QList<PartVariable*> part_vars_bk;  // backup list
    QStringList cabinet_types;
    QStringList variable_list;

    bool LoadSettings();
    bool SaveSettings();
    QList<int> GetCandidateCode();
    QStringList GetListPartVariable();

private:
    bool Serialize(QXmlStreamWriter* xmlWriter);
    bool Deserialize(QXmlStreamReader* xmlReader);
};

class PartVariable
{
public:
    PartVariable();

    QString PartType;
    QList<CodePair*> Codes;
    CodePair* GenCode();

    int nCode;
    char startChar;
};
#endif // SETTINGMODEL_H
