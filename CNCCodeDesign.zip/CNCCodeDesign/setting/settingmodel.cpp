#include <QFile>
#include <QSettings>
#include <QApplication>
#include <QDebug>
#include "settingmodel.h"
#include "defines.h"
#include "settingwindow.h"

#define PART_KEY        "Part"
#define CABINET_KEY     "Cabinet"
#define MATERIAL_KEY    "Material"

SettingModel* SettingModel::instance = NULL;
QString SettingModel::ProjectDir = "";
extern QStringList def_var;
const QStringList def_part_type = { "ADJUSTABLE SHELF", "BACK", "BOTTOM", "GABLE", "STRETCHER" };
const QStringList def_cab_type = { "LOWER", "UPPER", "CORNER", "TALL" };
const QStringList def_material = { "3/4 melamine", "Plywood", "PVC edging" };

SettingModel::SettingModel()
{
    ProjectDir = QCoreApplication::applicationDirPath();
}

bool SettingModel::LoadSettings()
{
    cabinet_types.clear();
    variable_list.clear();
    QString fname = QCoreApplication::applicationDirPath() + "/" + SETTING_FILE;
    QFile* xmlFile = new QFile(fname);
    if (!xmlFile->open(QIODevice::ReadOnly | QIODevice::Text)) {
        // file not found. Create default setting file
        for (int i = 0; i < def_var.count(); i++)
        {
            variable_list.append(def_var[i]);
        }

        for (int i = 0; i < def_cab_type.count(); i++)
        {
            cabinet_types.append(def_cab_type[i]);
        }
        return true;
    }
    QXmlStreamReader* xmlReader = new QXmlStreamReader(xmlFile);
    return Deserialize(xmlReader);
}

bool SettingModel::SaveSettings()
{
    SettingModel* sm = SettingModel::GetInstance();
    QString fname = QCoreApplication::applicationDirPath() + "/" + SETTING_FILE;
    QFile data(fname);
    if(data.open(QFile::WriteOnly |QFile::Truncate))
    {
        QXmlStreamWriter* xmlWriter = new QXmlStreamWriter(&data);
        xmlWriter->setAutoFormatting(true);
        xmlWriter->setAutoFormattingIndent(2);
        xmlWriter->writeStartDocument();
        Serialize(xmlWriter);
        xmlWriter->writeEndDocument();
    } else {
        return false;
    }
    data.close();

    return true;
}

QList<int> SettingModel::GetCandidateCode()
{
    QList<int> list;
    for (int i = 10; i <= 99; i++ )
        list.append(i);
    foreach (PartVariable* pv, part_vars) {
        list.removeOne(pv->nCode);
    }
    return list;
}

QStringList SettingModel::GetListPartVariable()
{
    QStringList list;
    foreach (PartVariable* pv, part_vars) {
        list.append(pv->PartType);
    }
    list.removeDuplicates();
    return list;
}


bool SettingModel::Serialize(QXmlStreamWriter* xmlWriter)
{
    xmlWriter->writeStartElement("settings");
    xmlWriter->writeStartElement("part_variables");
    foreach (PartVariable* var, part_vars) {
        xmlWriter->writeEmptyElement("type");
        xmlWriter->writeAttribute(NAME, var->PartType);
        xmlWriter->writeAttribute("code", QString::number(var->nCode));
        xmlWriter->writeAttribute("size", QString::number(var->Codes.count()));
    }
    xmlWriter->writeEndElement();   // end part_variables

    xmlWriter->writeStartElement("cabinet_types");
    foreach (QString str, cabinet_types) {
        xmlWriter->writeEmptyElement("ctype");
        xmlWriter->writeAttribute(NAME, str);
    }
    xmlWriter->writeEndElement();   // end cabinet_types

    xmlWriter->writeStartElement("variables");
    foreach (QString str, variable_list) {
        xmlWriter->writeEmptyElement("var");
        xmlWriter->writeAttribute(NAME, str);
    }
    xmlWriter->writeEndElement();   // end variables

    // end settings
    xmlWriter->writeEndElement();
    return true;
}

bool SettingModel::Deserialize(QXmlStreamReader* xmlReader)
{
    QXmlStreamReader::TokenType token;
    //Parse the XML until we reach end of it
    while(!xmlReader->atEnd() && !xmlReader->hasError())
    {
        token = xmlReader->tokenType();
        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument) {
            token = xmlReader->readNext();
            continue;
        } else if (token == QXmlStreamReader::StartElement)
        {
            QString name = xmlReader->name().toString();
            if (xmlReader->name() == "settings" ||
                    xmlReader->name() == "part_variables" ||
                    xmlReader->name() == "cabinet_types" ||
                    xmlReader->name() == "variables") {
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == "type") {
                PartVariable* pv = new PartVariable();
                if (xmlReader->attributes().hasAttribute("code"))
                    pv->nCode = xmlReader->attributes().value("code").toInt();
                if (xmlReader->attributes().hasAttribute(NAME))
                    pv->PartType = xmlReader->attributes().value(NAME).toString();
                if (xmlReader->attributes().hasAttribute("size"))
                {
                    int size = xmlReader->attributes().value("size").toInt();
                    for (int i = 0; i < size; i++)
                    {
                        CodePair* cp = new CodePair();
                        cp->Code = QString("MAT%1%2").arg(pv->nCode).arg(QChar('A' + i));
                        if (i == 0)
                            cp->pe = "Panel";
                        else
                            cp->pe = QString("Edge%1").arg(QChar('A' + i - 1));
                        pv->Codes.append(cp);
                    }
                }
                part_vars.append(pv);
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == "ctype"){
                if (xmlReader->attributes().hasAttribute(NAME))
                    cabinet_types.append(xmlReader->attributes().value(NAME).toString());
                xmlReader->readNextStartElement();
            } else if (xmlReader->name() == "var"){
                if (xmlReader->attributes().hasAttribute(NAME))
                    variable_list.append(xmlReader->attributes().value(NAME).toString());
                xmlReader->readNextStartElement();
            } else {
                xmlReader->raiseError(QString("setting.xml parse error unknown tag: ") + xmlReader->name().toString());
            }
        } else if (token == QXmlStreamReader::EndElement){
            if (xmlReader->name() == "settings")
                break;
            xmlReader->readNextStartElement();
        } else {
            xmlReader->readNextStartElement();
        }
    }

    if(xmlReader->hasError()) {
            QMessageBox::critical(nullptr,
            "XML parse error",xmlReader->errorString(),
            QMessageBox::Ok);
            return false;
    }
    return true;
}

PartVariable::PartVariable()
{
    PartType = "";
    nCode = SettingWindow::GenStartCode();
    startChar = 'A';
}

// Generate new code
CodePair* PartVariable::GenCode()
{
    if (startChar > 'Z')
        return nullptr;

    CodePair* cp = new CodePair();
    cp->Code = QString("MAT%1%2").arg(nCode).arg(startChar);
    if (Codes.count() == 0)
        cp->pe = "Panel";
    else
    {
        cp->pe = QString("Edge").append('A' + Codes.count() - 1);
    }
    Codes.append(cp);
    startChar++;
    return cp;
}
