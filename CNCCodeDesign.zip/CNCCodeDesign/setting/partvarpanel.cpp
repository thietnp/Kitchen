#include "partvarpanel.h"
#include "ui_partvarpanel.h"
#include "controlEx/decimalbox.h"
#include <QFocusEvent>
#include <QMenu>
#include <QSignalMapper>
#include "utils.h"

PartVarPanel* PartVarPanel::activedPanel = nullptr;
QString normalState = "background-color: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 1, stop: 0 #9dd, stop: 0.8 #dee)";
QString activeState = "background-color: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 1, stop: 0 #8bb, stop: 0.8 #cdd)";
PartVarPanel::PartVarPanel(PartVariable* var, QWidget *parent) :
    pv(var),
    QFrame(parent),
    ui(new Ui::PartVarPanel)
{
    ui->setupUi(this);
    setFocusProxy(ui->tableView);
    setStyleSheet(normalState);
    //activeIndex = nullptr;

    model = new QStandardItemModel(this);
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("")));
    ui->tableView->setItemDelegateForColumn(1, new NotEditableDelegate());
    ui->tableView->setItemDelegateForColumn(2, new NotEditableDelegate());
    ui->tableView->setModel(model);

    foreach (CodePair* cp, pv->Codes) {
        AppendRow(cp);
    }
}

PartVarPanel::~PartVarPanel()
{
    delete ui;
}

void PartVarPanel::AppendRow(CodePair* code)
{
    QStandardItem *item = new QStandardItem(pv->PartType);
    int row = model->rowCount();

    model->appendRow(item);
    if (code != nullptr)
    {
        model->setItem(row, 1, new QStandardItem(code->pe));
        model->setItem(row, 2, new QStandardItem(code->Code));
    }
    if (model->rowCount() > 1)
       ui->tableView->setSpan(0, 0, row + 1, 1);
}

void PartVarPanel::SetActive(bool isActive)
{
    if (isActive)
    {
        if (activedPanel != nullptr)
            activedPanel->setStyleSheet(normalState);
        activedPanel = this;
        activedPanel->setStyleSheet(activeState);
    }
}

void PartVarPanel::mousePressEvent(QMouseEvent *event)
{
    SetActive(true);
}


void PartVarPanel::on_btnAdd_clicked()
{
    AppendRow(pv->GenCode());
}

void PartVarPanel::on_tableView_pressed(const QModelIndex &index)
{
    SetActive(true);
}

void PartVarPanel::on_tableView_doubleClicked(const QModelIndex &index)
{
    if (index.column() == 2)
    {
        activeIndex =  index;
        SettingModel* sm = SettingModel::GetInstance();
        QMenu* menu = new QMenu(ui->tableView);
        QSignalMapper* map = new QSignalMapper();
        QList<int> list = sm->GetCandidateCode();
        foreach (int val, list) {
            QAction* act = menu->addAction(QString::number(val), map, SLOT(map()));
            map->setMapping(act, val);
        }
        connect(map, SIGNAL(mapped(int)), this, SLOT(on_selectNewCode(int)));
        menu->popup(QCursor::pos());
    }
}

void PartVarPanel::on_selectNewCode(int n)
{
    pv->nCode = n;

    for (int i = 0; i < model->rowCount(); i++)
    {
        QString newcode = QString("MAT%1%2").arg(n).arg(QChar('A' + i));
        model->setItem(i, activeIndex.column(), new QStandardItem(newcode));
        pv->Codes[i]->Code = newcode;
    }
}
