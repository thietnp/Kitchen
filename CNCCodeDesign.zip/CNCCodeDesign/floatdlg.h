#ifndef FLOATDLG_H
#define FLOATDLG_H

#include <QDialog>
#include "document.h"
#include "cabinetpage.h"
#include "partpage.h"

namespace Ui {
class FloatDlg;
}

class FloatDlg : public QDialog
{
    Q_OBJECT

public:
    explicit FloatDlg(QWidget *parent = 0);
    ~FloatDlg();

    void SetDocument(Document* d, Document* org);

signals:
    void docChanged(Document* d, Document* org);
protected:
    void closeEvent(QCloseEvent *) override;

private:
    Ui::FloatDlg *ui;
    Document* doc;
    Document* doc_org;      //original document
    BasePage* page;

private slots:
    void saveDoc();
};

#endif // FLOATDLG_H
