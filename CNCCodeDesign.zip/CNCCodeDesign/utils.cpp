
#include <QApplication>
#include <QFile>
#include "utils.h"

void SetWidgetStyle(QWidget* widget, QString fname)
{
    QString path = QCoreApplication::applicationDirPath() + "/res/" + fname;
    QFile File(path);
    File.open(QFile::ReadOnly);
    QString StyleSheet = QLatin1String(File.readAll());
    File.close();

    widget->setStyleSheet(StyleSheet);
}

// Get next file with a count variable
QString GetNextFile(QString path)
{
    int cnt = 1;
    QFileInfo check_file(path);
    if (!check_file.exists())
        return path;
    QString newfile = path;
    while (true)
    {
        if (check_file.completeSuffix() != "")
            newfile = check_file.dir().absolutePath() + "/" + check_file.baseName() + QString::number(cnt) + "." + check_file.completeSuffix();
        else
            newfile = check_file.dir().absolutePath() + "/" + check_file.baseName() + QString::number(cnt);
        QFileInfo check_file2(newfile);
        if (!check_file2.exists())
            break;
        cnt++;
    }
    return newfile;
}

void copyPath(QString src, QString dst)
{
    QDir dir(src);
    if (! dir.exists())
        return;

    foreach (QString d, dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        QString dst_path = dst + QDir::separator() + d;
        dir.mkpath(dst_path);
        copyPath(src+ QDir::separator() + d, dst_path);
    }

    foreach (QString f, dir.entryList(QDir::Files)) {
        QFile::copy(src + QDir::separator() + f, dst + QDir::separator() + f);
    }
}

QString GetCabinetFile(QString dir)
{
    QDir directory(dir);
    QStringList cbn_files = directory.entryList(QStringList() << "*.cbn" << "*.CBN",QDir::Files);
    if (cbn_files.count() > 0)
        return dir + QDir::separator() + cbn_files[0];
    else
        return "";
}
