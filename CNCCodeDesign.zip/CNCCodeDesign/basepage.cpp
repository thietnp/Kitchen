#include "basepage.h"

BasePage::BasePage(QWidget *parent) : QWidget(parent)
{

}

void BasePage::UpdateSettings()
{

}

void BasePage::on_PageActived()
{

}
