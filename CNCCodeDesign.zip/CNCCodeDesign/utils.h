#ifndef UTILS_H
#define UTILS_H
#include <QDir>
#include <QDebug>
#include <QDialog>
#include <QFileDialog>
#include <QApplication>
#include <QMessageBox>
#include "defines.h"

extern QString SystemStyle;
extern QString Workspace;
extern QString LINEFEED;
void SetWidgetStyle(QWidget* widget, QString fname);
QString GetNextFile(QString path);
void copyPath(QString src, QString dst);
QString GetCabinetFile(QString dir);

#endif // UTILS_H
