#ifndef DECIMALBOX_H
#define DECIMALBOX_H
#include <QLineEdit>
#include <QItemDelegate>

class DecimalBox : public QItemDelegate
{
    Q_OBJECT
public:
    explicit DecimalBox(QWidget *parent = nullptr, double _min = 0, double _max = 999.999, int dec = 3);

    QWidget *createEditor(QWidget *parent,
                          const QStyleOptionViewItem &option,
                          const QModelIndex &index) const override;
private:
    int min, max, decimal;
signals:

public slots:
};

class NotEditableDelegate : public QItemDelegate
{
    Q_OBJECT
public:
    explicit NotEditableDelegate(QObject *parent = 0)
        : QItemDelegate(parent)
    {}

protected:
    bool editorEvent(QEvent *event, QAbstractItemModel *model, const QStyleOptionViewItem &option, const QModelIndex &index)
    { return false; }
    QWidget* createEditor(QWidget *, const QStyleOptionViewItem &, const QModelIndex &) const
    { return Q_NULLPTR; }

};
#endif // DECIMALBOX_H
