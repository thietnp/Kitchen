#include "controlEx/decimalbox.h"
#include <QDoubleValidator>

DecimalBox::DecimalBox(QWidget *parent, double _min, double _max, int dec) : QItemDelegate(parent),
    min(_min),
    max(_max),
    decimal(dec)
{
}

QWidget* DecimalBox::createEditor(QWidget *parent,
                      const QStyleOptionViewItem &option,
                      const QModelIndex &index) const
{
    QLineEdit* edit = new QLineEdit(parent);
    QDoubleValidator* validation = new QDoubleValidator(min, max, decimal);
    edit->setValidator(validation);
    return edit;
}
