#ifndef BASEPAGE_H
#define BASEPAGE_H

#include <QWidget>

class BasePage : public QWidget
{
    Q_OBJECT
public:
    explicit BasePage(QWidget *parent = nullptr);

    enum Mode {
        MODE_EDIT,
        MODE_VIEW
    };

    virtual bool UpdateData(bool save) { return true;}

protected:
    Mode mode;
signals:
    void updateTitle();
public slots:
    virtual void UpdateSettings();
    virtual void on_PageActived();
};

#endif // BASEPAGE_H
