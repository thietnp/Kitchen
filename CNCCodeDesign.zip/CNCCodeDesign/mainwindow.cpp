#include <QLayout>
#include <QStyleOption>
#include <QStackedWidget>
#include <QFile>
#include <QLayout>
#include <QScrollArea>
#include <QPushButton>
#include <QIcon>
#include <QMessageBox>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "partpage.h"
#include "verticaltabstyle.h"
#include "cabinetpage.h"
#include "kitchenpage.h"
#include "settingwindow.h"
#include "settingmodel.h"
#include "utils.h"

QString SystemStyle = "system_style.qss";
QString Workspace;
MainWindow* MainWindow::g_mainWindow = nullptr;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    g_mainWindow = this;
    ui->setupUi(this);
    InitApp();

    QStackedWidget* mainlayout = new QStackedWidget(this->centralWidget());

    tabWidget = new QTabWidget(this->centralWidget());
    tabWidget->setTabPosition(QTabWidget::West);
    tabWidget->tabBar()->setStyle(new VerticalTabStyle());
    SetWidgetStyle(tabWidget, "main_tab_style.qss");

    tabWidget->addTab(new QWidget(), "TAB 1");
    tabWidget->addTab(new QWidget(), "TAB 2");
    tabWidget->addTab(new QWidget(), "TAB 3");
    tabWidget->addTab(new QWidget(), "TAB 4");

    // Tab optimizing
    page_otm = new OptimizePage(tabWidget);
    AddPage(page_otm, "Optimize");
    //SetWidgetStyle(page_ktc, SystemStyle);

    // Tab kitchen
    page_ktc = new KitchenPage(tabWidget);
    AddPage(page_ktc, "Kitchen");
    //SetWidgetStyle(page_ktc, SystemStyle);
    //SetWidgetStyle(page_ktc, "label_style1.qss");
    // Create blank kitchen
    Kitchen* kdoc = new Kitchen();
    page_ktc->LoadDocument(kdoc);

    page_cab = new CabinetPage(PartPage::MODE_EDIT, tabWidget);
    AddPage(page_cab, "Cabinet");
    SetWidgetStyle(page_cab, SystemStyle);
    SetWidgetStyle(page_cab, "label_style1.qss");
    // Create blank cabinet
    Cabinet* cdoc = new Cabinet();
    page_cab->LoadDocument(cdoc);

    page_part = new PartPage(PartPage::MODE_EDIT, tabWidget);
    AddPage(page_part, "Part");
    SetWidgetStyle(page_part, SystemStyle);
    SetWidgetStyle(page_part, "label_style1.qss");
    // Create blank part
    Part* pnew = new Part(this);
    page_part->LoadDocument(pnew);

    tabWidget->setCurrentIndex(7);
    mainlayout->addWidget(tabWidget);

    QPixmap pixmap(":/res/setting.png");
    QIcon ButtonIcon(pixmap);

    btnSetting = new QPushButton(ButtonIcon, "", tabWidget);
    btnSetting->setIcon(ButtonIcon);
    btnSetting->setIconSize(QSize(50, 50));
    btnSetting->setFixedSize(60, 60);
    btnSetting->show();
    btnSetting->move(20, this->height() - 90);
    connect(btnSetting, SIGNAL(clicked(bool)), this, SLOT(on_btnSettingClicked()));
    connect(tabWidget, SIGNAL(currentChanged(int)), this, SLOT(on_TabSelChanged(int)));

    this->setCentralWidget(mainlayout);
    this->showMaximized();

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::InitApp()
{
    // Load settings
    SettingModel* sm = SettingModel::GetInstance();
    sm->LoadSettings();

    QDir dir;
    dir.mkpath(SettingModel::ProjectDir);
    QString cabinets = SettingModel::GetCabinetsDir();
    dir.mkpath(cabinets);
    QString parts = SettingModel::GetPartsDir();
    dir.mkpath(parts);
    QString ktc = SettingModel::GetKitchensDir();
    dir.mkpath(ktc);
}

void MainWindow::AddPage(BasePage *page, QString title)
{
    QStackedWidget* wrapper = new QStackedWidget(tabWidget);
    wrapper->addWidget(page);
    tabWidget->addTab(wrapper, title);
    pages.append(page);
    connect(page, SIGNAL(updateTitle()), this, SLOT(UpdateTitle()));
}

// Add tab page with scroll bars
// To be removed
//void MainWindow::AddScrollPage(QWidget *page, QString title)
//{
//    QScrollArea* scroll = new QScrollArea;
//    scroll->setWidgetResizable(true);
//    scroll->setWidget(page);
//    tabWidget->addTab(scroll, title);
//}

void MainWindow::ActivePage(int idx)
{
    tabWidget->setCurrentIndex(idx);
}

void MainWindow::UpdateSystemSettings()
{
    foreach (BasePage* p, pages) {
        p->UpdateSettings();
    }
}

void MainWindow::UpdateTitle()
{
    QString title;
    int idx = tabWidget->currentIndex();
    switch (idx) {
    case 4:
        setWindowTitle("Optimize");
        break;
    case 5:
        title = QString("Kitchen ") + page_ktc->GetDocument()->JobID;
        if (page_ktc->GetDocument()->IsModified())
            title += "*";
        setWindowTitle(title);
        break;
    case 6:
        title = QString("Cabinet ") + page_cab->GetDocument()->Name;
        if (page_cab->GetDocument()->IsModified())
            title += "*";
        setWindowTitle(title);
        break;
    case 7:
        title = QString("Part ") + page_part->GetDocument()->Name;
        if (page_part->GetDocument()->IsModified())
            title += "*";
        setWindowTitle(title);
        break;
    default:
        setWindowTitle("CNC Code Design");
        break;
    }
}

void MainWindow::resizeEvent(QResizeEvent* event)
{
   QMainWindow::resizeEvent(event);
   btnSetting->move(5, height() - 100);
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    bool close = true;
    close &= page_part->SaveModified();
    if (close)
        close &= page_cab->SaveModified();
    if (close)
        close &= page_ktc->SaveModified();

    if (!close)
    {
        event->ignore();
        return;
    }
    QMainWindow::closeEvent(event);
}

void MainWindow::on_btnSettingClicked()
{
    page_part->UpdateData(true);
    SettingWindow settingWnd(WS_MODE_EDIT, this);
    int ret = settingWnd.exec();
    if (ret == QDialog::Rejected)
        return;

    this->UpdateSystemSettings();
}

void MainWindow::on_TabSelChanged(int idx)
{
    this->UpdateTitle();
}
