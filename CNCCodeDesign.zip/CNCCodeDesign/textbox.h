#ifndef TEXTBOX_H
#define TEXTBOX_H
#include <basebox.h>

class TextBox : public BaseBox
{
    //Q_OBJECT
public:
    explicit TextBox(QWidget* parent);
    virtual ~TextBox();

};

#endif // TEXTBOX_H
