#include "numbox.h"
#include <QPalette>

NumBox::NumBox(QWidget* parent) : BaseBox(parent)
{

}

NumBox::~NumBox()
{

}

