#include "floatdlg.h"
#include "ui_floatdlg.h"
#include "utils.h"
#include <QCloseEvent>
#include "cabinetpage.h"
#include "partpage.h"
#include "materialeditwnd.h"

FloatDlg::FloatDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FloatDlg)
{
    ui->setupUi(this);
    page = nullptr;
}

FloatDlg::~FloatDlg()
{
    delete ui;
}

void FloatDlg::SetDocument(Document* d, Document* org)
{
    doc = d;
    doc_org = org;
    if (qobject_cast<Cabinet*>(doc) != nullptr)
    {
        CabinetPage* cabpage = new CabinetPage(PartPage::MODE_VIEW);
        Cabinet* cab_doc = qobject_cast<Cabinet*>(doc);
        cabpage->LoadDocument(cab_doc);
        ui->verticalLayout->addWidget(cabpage);
        connect(cabpage, SIGNAL(saveDoc(Document*)), this, SLOT(saveDoc()));
        page = cabpage;

    } else if (qobject_cast<Part*>(doc) != nullptr)
    {
        PartPage* partpage = new PartPage(PartPage::MODE_VIEW);
        Part* part_doc = qobject_cast<Part*>(doc);
        partpage->LoadDocument(part_doc);
        ui->verticalLayout->addWidget(partpage);
        connect(partpage, SIGNAL(saveDoc(Document*)), this, SLOT(saveDoc()));
        page = partpage;
    } else if (qobject_cast<Kitchen*>(doc) != nullptr)
    {
        Kitchen* kit = qobject_cast<Kitchen*>(doc);
        MaterialEditWnd* matpage = new MaterialEditWnd(kit, PartPage::MODE_VIEW);
        ui->verticalLayout->addWidget(matpage);
        connect(matpage, SIGNAL(saveDoc(Document*)), this, SLOT(saveDoc()));
        page = matpage;
    }
    else {
        qDebug() << "FloatDlg: unrecognize document";
    }
}

void FloatDlg::closeEvent(QCloseEvent *e)
{    
    if (page != nullptr)
        page->UpdateData(true);

    if (doc->IsModified())
    {
        QMessageBox::StandardButton reply = QMessageBox::question(NULL, "Confirm", "This document has been modified. Do you want to save?",
                        QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        if (reply == QMessageBox::Yes)
        {
            QDialog::closeEvent(e);
            // Notify document has changed
            emit docChanged(doc, doc_org);
        } else if (reply == QMessageBox::Cancel) {
            // Don't close dialog
            e->ignore();
        }
    }
}

void FloatDlg::saveDoc()
{
    emit docChanged(doc, doc_org);
}
