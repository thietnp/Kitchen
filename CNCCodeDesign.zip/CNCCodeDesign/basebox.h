#ifndef BASEBOX_H
#define BASEBOX_H

#include <QWidget>
#include <QLineEdit>
#include <QColor>

#include "defines.h"

class BaseBox : public QLineEdit
{
    //Q_OBJECT
public:
    explicit BaseBox(QWidget* parent = nullptr);
    virtual ~BaseBox();

    void AutoSize();
protected:
    void contextMenuEvent(QContextMenuEvent *event) override;
    void dropEvent(QDropEvent *e) override;

};

#endif // BASEBOX_H
