#include "textbox.h"

TextBox::TextBox(QWidget* parent) : BaseBox(parent)
{

}

TextBox::~TextBox()
{

}

