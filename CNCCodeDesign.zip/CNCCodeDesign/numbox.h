#ifndef NUMBOX_H
#define NUMBOX_H
#include <basebox.h>

class NumBox : public BaseBox
{
    //Q_OBJECT
public:
    explicit NumBox(QWidget* parent);
    virtual ~NumBox();
};

#endif // NUMBOX_H
