#ifndef VARIABLELINE_H
#define VARIABLELINE_H

#include <QWidget>
#include <QToolButton>
#include <QPushButton>
#include <QLineEdit>

namespace Ui {
class VariableLine;
}

// class of Variable model
class VarModel
{
public:
    VarModel(QString name, QString value) : Name(name), Value(value){}

    QString Name;
    QString Value;
};

class VariableLine : public QWidget
{
    Q_OBJECT

public:
    explicit VariableLine(QWidget *parent = 0);
    ~VariableLine();
    void SetName(QString name);
    QString GetValue();
    void SetModel(VarModel* model);
    void UpdateData(bool save = true);
    void SetMenuView(QMenu* menu);
    void SetMenuPart(QMenu* menu);

    VarModel* vm;
signals:
    void click_remove();
    void edit_value(const QString& str);
private slots:
    void on_btnRm_clicked();

    void on_editValue_textChanged(const QString &arg1);

private:
    Ui::VariableLine *ui;

};

#endif // VARIABLELINE_H
