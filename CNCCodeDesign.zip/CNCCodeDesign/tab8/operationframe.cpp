#include <QVBoxLayout>
#include <QDebug>
#include "operationframe.h"
#include "ui_operationframe.h"
#include "partpage.h"
#include "mainwindow.h"

OperationFrame::OperationFrame(QString _title, QWidget *parent) :
    QFrame(parent),
    ui(new Ui::OperationFrame),
    title(_title)
{
    ui->setupUi(this);
    lbl_title = new ClickableLabel(ui->widget);
            lbl_title->setObjectName(QStringLiteral("lbl_title"));
            lbl_title->setGeometry(QRect(10, 10, 221, 41));
            lbl_title->setMargin(5);

    lbl_title->setText(title);
    lbl_title->setStyleSheet("border-width: 1px;"
                                 "border-style: solid;"
                                 "border-color: black;"
                                 "background-color: red;");
    lbl_title->adjustSize();
    lbl_title->setMinimumWidth(100);
    lbl_title->show();

    connect(lbl_title, SIGNAL(clicked()), this, SLOT(header_clicked()));

    SelRow = 0;
}

OperationFrame::~OperationFrame()
{
    delete ui;
}

//=========================================
// Line's menu
void OperationFrame::on_NewLineAbove()
{
    LineData* newline = new LineData(opedata);
    InsertLine(newline, SelRow);
}

void OperationFrame::on_NewLineBellow()
{
    LineData* newline = new LineData(opedata);
    InsertLine(newline, SelRow + 1);
}

void OperationFrame::on_CopyLine()
{
    LineData* newline = Lines[SelRow]->GetData()->Clone(Lines[SelRow]->GetData());
    InsertLine(newline, SelRow + 1);
}

void OperationFrame::on_MoveLineUp()
{
    if (SelRow == 0)
        return;

    // Swap gui
    LinePanel* form = Lines[SelRow];
    ui->verticalLayout_2->removeWidget(form);
    ui->verticalLayout_2->insertWidget(SelRow - 1, form);
    Lines.removeAt(SelRow);
    Lines.insert(SelRow -1, form);

    // Swap data
    LineData* ld = opedata->Lines[SelRow];
    opedata->Lines.removeAt(SelRow);
    opedata->Lines.insert(SelRow - 1, ld);

    UpdateLayout();
    SetDocModified();
}

void OperationFrame::on_MoveLineDown()
{
    if (SelRow == Lines.size() - 1)
        return;

    // Swap gui
    LinePanel* form = Lines[SelRow];
    ui->verticalLayout_2->removeWidget(form);
    ui->verticalLayout_2->insertWidget(SelRow + 1, form);
    Lines.removeAt(SelRow);
    Lines.insert(SelRow + 1, form);

    // Swap data
    LineData* ld = opedata->Lines[SelRow];
    opedata->Lines.removeAt(SelRow);
    opedata->Lines.insert(SelRow + 1, ld);

    UpdateLayout();
    SetDocModified();
}

void OperationFrame::on_DeleteLine()
{
    if (SelRow < 0 || SelRow >= Lines.size())
        return;
    this->opedata->Lines.removeAt(SelRow);
    LinePanel* form = Lines[SelRow];
    ui->verticalLayout_2->removeWidget(form);
    if (SelRow >= 0 && SelRow < Lines.size())
        Lines.removeAt(SelRow);
    if (Lines.size() - 1 < SelRow)
        SelRow--;
    delete form;
    UpdateLayout();
    SetDocModified();
}

void OperationFrame::SetCurrentSelect(LinePanel* form)
{
    SelRow = Lines.indexOf(form);
}

int OperationFrame::GetMaxBoxes()
{
    int max = 0;
    for(LinePanel* form : Lines)
    {
        max = qMax(max, form->Items.size());
    }
    return max;
}

void OperationFrame::InsertLine(LineData* line_data, int idx)
{
    LinePanel* line = new LinePanel(this);
    line->SetData(line_data);
    if (idx < 0)
        idx = Lines.count();
    opedata->Lines.insert(idx, line_data);
    ui->verticalLayout_2->insertWidget(idx, line);
    Lines.insert(idx, line);
    UpdateLayout();
    SetDocModified();
    connect(line, SIGNAL(data_changed()), this, SLOT(SetDocModified()));
}

void OperationFrame::SetDocModified()
{
    emit data_changed();
}

void OperationFrame::SetData(OperationData* data)
{
    opedata = data;
    // Clear current data
    for (LinePanel* line : Lines)
    {
        ui->verticalLayout_2->removeWidget(line);
        delete line;
    }
    Lines.clear();

    // Insert new data
    for (LineData* ldata : data->Lines)
    {
        //InsertLine(ldata);
        LinePanel* line = new LinePanel(this);
        line->SetData(ldata);
        int idx = Lines.count();
        ui->verticalLayout_2->insertWidget(idx, line);
        Lines.insert(idx, line);
        connect(line, SIGNAL(data_changed()), this, SLOT(SetDocModified()));
    }
}

void OperationFrame::WriteData(QString filename)
{
    QFile data(filename);
    if(data.open(QFile::WriteOnly |QFile::Truncate))
    {
    QTextStream output(&data);

    }
}

void OperationFrame::UpdateLayout()
{
    this->setMinimumHeight(HEADER_HEIGHT + (Lines.size() * FORM_HEIGH));
    repaint();
}

bool OperationFrame::event(QEvent *evt)
{
    return QWidget::event(evt);
}

void OperationFrame::header_clicked()
{
    LineData* newline = new LineData(opedata);
    InsertLine(newline, Lines.count());
    UpdateLayout();
}

