#include "tab8/variableline.h"
#include "ui_variableline.h"
#include <QValidator>

VariableLine::VariableLine(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VariableLine)
{
    ui->setupUi(this);
    QDoubleValidator* validation = new QDoubleValidator(0, 999.999, 3);
    ui->editValue->setValidator(validation);
}

VariableLine::~VariableLine()
{
    delete ui;
}

void VariableLine::SetName(QString name)
{
    vm->Name = name;
    ui->label->setText(name);
}

QString VariableLine::GetValue()
{
    return ui->editValue->text();
}

void VariableLine::SetModel(VarModel* model)
{
    vm = model;
    ui->label->setText(vm->Name);
    ui->editValue->setText(vm->Value);
}

void VariableLine::UpdateData(bool save)
{
    if (save)
    {
        vm->Value = ui->editValue->text();
    }
    else
    {
        ui->editValue->setText(vm->Value);
    }
}

void VariableLine::SetMenuView(QMenu* menu)
{
    ui->btnView->setMenu(menu);
}

void VariableLine::SetMenuPart(QMenu* menu)
{
    ui->btnPart->setMenu(menu);
}

void VariableLine::on_btnRm_clicked()
{
    emit click_remove();
}

void VariableLine::on_editValue_textChanged(const QString &arg1)
{
    emit edit_value(arg1);
}
