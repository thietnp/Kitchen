#ifndef OPERATIONFRAME_H
#define OPERATIONFRAME_H

#include <QFrame>
#include "linepanel.h"
#include "clickablelabel.h"
#include "operationdata.h"

namespace Ui {
class OperationFrame;
}

class OperationFrame : public QFrame
{
    Q_OBJECT

public:
    explicit OperationFrame(QString _title, QWidget *parent = 0);
    ~OperationFrame();

public:
    QList<LinePanel*> Lines;
    int SelRow;
    ClickableLabel* lbl_title;

private:
    Ui::OperationFrame *ui;
    QString title;
    OperationData* opedata;

protected:
    bool event( QEvent *evt ) override;

public:
    void SetData(OperationData* data);
    void WriteData(QString filename);
    void UpdateLayout();
    void SetCurrentSelect(LinePanel* form);
    int GetMaxBoxes();
    void InsertLine(LineData* line_data, int idx = -1);

    // Line's menu
    void on_NewLineAbove();
    void on_NewLineBellow();
    void on_CopyLine();
    void on_MoveLineUp();
    void on_MoveLineDown();
    void on_DeleteLine();

signals:
    void data_changed();

public slots:
    void header_clicked();
    void SetDocModified();
};

#endif // OPERATIONFRAME_H
