#include <QMenu>
#include <QDebug>
#include <QMessageBox>

#include "linepanel.h"
#include "ui_linepanel.h"
#include "partpage.h"
#include "numbox.h"
#include "textbox.h"
#include "operationframe.h"
#include "mainwindow.h"

LinePanel::LinePanel(QWidget *parent) :
    QGroupBox(parent),
    ui(new Ui::LinePanel)
{
    lData = NULL;
    ui->setupUi(this);
    ui->horizontalLayout_2->addStretch();
    ui->horizontalLayout->setSpacing(2);
    ui->horizontalLayout->setAlignment(Qt::AlignTop);
    this->setStyleSheet("QGroupBox {\n"
                        "background: qlineargradient(x1:0, y1:0, x2:1, y2:1,stop:0 white, stop: 0.4 rgba(20, 30, 10, 40), stop:1 rgb(100, 160, 230, 200));\n}");
    // Line's menu
    QMenu* lmenu = new QMenu();
    lmenu->addAction(tr("New Line &Above"), this, SLOT(on_NewLineAbove()));
    lmenu->addAction(tr("New Line &Below"), this, SLOT(on_NewLineBellow()));
    lmenu->addAction(tr("&Copy Line"), this, SLOT(on_CopyLine()));
    lmenu->addAction(tr("Move Line &Up"), this, SLOT(on_MoveLineUp()));
    lmenu->addAction(tr("Move Line &Down"), this, SLOT(on_MoveLineDown()));
    lmenu->addSeparator();
    lmenu->addAction(tr("D&elete Line"), this, SLOT(on_DeleteLine()));
    ui->btnActions->setMenu(lmenu);
}

LinePanel::~LinePanel()
{
    delete ui;
}

void LinePanel::SetData(LineData* data)
{
    lData = data;
    bool ok = false;
    BaseBox* box = nullptr;
    for (QString str : lData->Boxes)
    {
        box = new TextBox(this);
        box->setText(str);
        InsertBox(box);
        box->AutoSize();
    }
}

// Insert box to line. idx = -1 mean that insert at the end of line.
void LinePanel::InsertBox(BaseBox* box, int idx)
{
    if (idx < 0)
        idx = Items.size();
    if (idx > Items.size())
        return;

    ui->horizontalLayout->insertWidget(idx, box);
    box->show();

    Items.insert(idx, box);
    UpdateLayout();
    emit data_changed();
}

void LinePanel::UpdateLayout()
{
    QWidget* p = parentWidget();
    OperationFrame* frame = qobject_cast<OperationFrame*>(p);
    if (frame != NULL)
        frame->UpdateLayout();
}

void LinePanel::on_btnAddText_clicked()
{
    lData->Boxes.append("");
    TextBox* box = new TextBox(this);
    InsertBox(box);
    box->setFocus();
}

void LinePanel::on_btnAddNum_clicked()
{
    lData->Boxes.append("");
    NumBox* box = new NumBox(this);
    InsertBox(box);
    box->setFocus();
}

void LinePanel::on_NewLineAbove()
{
    ((OperationFrame*)parent())->SetCurrentSelect(this);
    ((OperationFrame*)parent())->on_NewLineAbove();
}

void LinePanel::on_NewLineBellow()
{
    ((OperationFrame*)parent())->SetCurrentSelect(this);
    ((OperationFrame*)parent())->on_NewLineBellow();
}

void LinePanel::on_CopyLine()
{
    ((OperationFrame*)parent())->SetCurrentSelect(this);
    ((OperationFrame*)parent())->on_CopyLine();
}
void LinePanel::on_MoveLineUp()
{
    ((OperationFrame*)parent())->SetCurrentSelect(this);
    ((OperationFrame*)parent())->on_MoveLineUp();
}

void LinePanel::on_MoveLineDown()
{
    ((OperationFrame*)parent())->SetCurrentSelect(this);
    ((OperationFrame*)parent())->on_MoveLineDown();
}

void LinePanel::on_DeleteLine()
{
    ((OperationFrame*)parent())->SetCurrentSelect(this);
    ((OperationFrame*)parent())->on_DeleteLine();
}

void LinePanel::on_TextBefore()
{
    BaseBox* box = (BaseBox*)((QAction*)sender())->parent()->parent();
    if( box != NULL )
    {
        int idx = Items.indexOf(box);
        lData->Boxes.insert(idx, "");
        InsertBox(new TextBox(this), idx);
    }
}

void LinePanel::on_TextAfter()
{
    BaseBox* box = (BaseBox*)((QAction*)sender())->parent()->parent();
    if( box != NULL )
    {
        int idx = Items.indexOf(box) + 1;
        lData->Boxes.insert(idx, "");
        InsertBox(new TextBox(this), idx);
    }
}

void LinePanel::on_NumBefore()
{
    BaseBox* box = (BaseBox*)((QAction*)sender())->parent()->parent();
    if( box != NULL )
    {
        int idx = Items.indexOf(box);
        lData->Boxes.insert(idx, "");
        InsertBox(new NumBox(this), idx);
    }
}

void LinePanel::on_NumAfter()
{
    BaseBox* box = (BaseBox*)((QAction*)sender())->parent()->parent();
    if( box != NULL )
    {
        int idx = Items.indexOf(box) + 1;
        lData->Boxes.insert(idx, "");
        InsertBox(new NumBox(this), idx);
    }
}

void LinePanel::on_CopyContent()
{
    BaseBox* box = (BaseBox*)((QAction*)sender())->parent()->parent();
    box->selectAll();
    box->copy();
}

void LinePanel::on_PasteContent()
{
    BaseBox* box = (BaseBox*)((QAction*)sender())->parent()->parent();
    box->paste();
}

void LinePanel::on_DeleteBox()
{
    BaseBox* box = (BaseBox*)((QAction*)sender())->parent()->parent();
    if( box != NULL )
    {
        int idx = Items.indexOf(box);
        if (idx < 0)
            return;

        lData->Boxes.removeAt(idx);
        ui->horizontalLayout->removeWidget(box);
        Items.removeAt(idx);
        UpdateLayout();
        ui->horizontalLayout->update();
        box->deleteLater();
        emit data_changed();
    }
}

//bool LinePanel::event( QEvent *evt )
//{
//    //qDebug() << evt;
//    return QGroupBox::event(evt);
//}

void LinePanel::on_textChanged()
{
    // Check whether this object is detroying
    if (lData == nullptr)
        return;

    QObject* obj = sender();
    BaseBox* edit = (BaseBox*)(obj);
    if (edit == NULL)
        return;
    int idx = Items.indexOf(edit);
    if (idx < 0)
        return;
    QString text = edit->text();
    if (text.contains(','))
    {
        edit->setText(lData->Boxes[idx]);
        QMessageBox msg;
        msg.warning(QApplication::activeWindow(), "Warning", "Cannot input a comma", QMessageBox::Ok);
        return;
    }
    // Check change
    if (lData->Boxes[idx] == ((BaseBox*)obj)->text())
        return;

    lData->Boxes[idx] = ((BaseBox*)obj)->text();

    // Fit content
    edit->AutoSize();

    // notify data has changed
    emit data_changed();
}
