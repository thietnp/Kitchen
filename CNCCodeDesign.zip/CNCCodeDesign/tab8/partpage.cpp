#include <QMenu>
#include <QLayout>
#include <QTextStream>
#include <QShortcut>
#include <QMimeData>
#include <QCursor>
#include <QDrag>
#include "partpage.h"
#include "ui_partpage.h"
#include "textbox.h"
#include "numbox.h"
#include "utils.h"
#include "settingmodel.h"
#include <QSignalMapper>
#include "cabinetpage.h"
#include "mainwindow.h"
#include "settingwindow.h"

QStringList str_Operations = {"DRILL HOLE",
                            "Use Tool 1",
                            "Use Tool 2",
                            "Use Tool 3",
                            "Use Tool 4",
                            "Use Tool 5",
                            "Use Tool 6",
                            "Use Tool 7",
                            "Use Tool 8",
                            "SKIN CUT",
                            "FINAL PART CUT",
                           };

extern QStringList def_var;

PartPage::PartPage(Mode _mode, QWidget *parent) :
    BasePage(parent),
    ui(new Ui::PartPage)
{
    ui->setupUi(this);
    mode = _mode;
    doc = nullptr;
    btnNewVar = nullptr;

    SetWidgetStyle(this, SystemStyle);
    QStringList list = SettingModel::GetInstance()->GetListPartVariable();
    ui->cbPartType->addItems(list);

    if (mode == MODE_EDIT)
    {
        ui->btnSave->hide();
        // Part's menu
        QMenu* pmenu = new QMenu();
        QAction* a1 = pmenu->addAction(tr("Open Part\tCtrl+O"), this, SLOT(On_OpenPart()));
        QAction* a2 = pmenu->addAction(tr("Save Part\tCtrl+S"), this, SLOT(On_SavePart()));
        QAction* a3 = pmenu->addAction(tr("Save Part As\tCtrl+Alt+S"), this, SLOT(On_SavePartAs()));
        QAction* a4 = pmenu->addAction(tr("Create G-Code\tCtrl+G"), this, SLOT(On_CreateGCode()));
        QAction* a5 = pmenu->addAction(tr("Save And Exit\tCtrl+Q"), this, SLOT(On_SaveAndExit()));
        ui->btnPart->setMenu(pmenu);

        QShortcut *open = new QShortcut(QKeySequence("Ctrl+O"), this);
        connect(open, SIGNAL(activated()), this, SLOT(On_OpenPart()));
        QShortcut *saveas = new QShortcut(QKeySequence("Ctrl+Alt+S"), this);
        connect(saveas, SIGNAL(activated()), this, SLOT(On_SavePartAs()));
        QShortcut *gcode = new QShortcut(QKeySequence("Ctrl+G"), this);
        connect(gcode, SIGNAL(activated()), this, SLOT(On_CreateGCode()));
        QShortcut *savequit = new QShortcut(QKeySequence("Ctrl+Q"), this);
        connect(savequit, SIGNAL(activated()), this, SLOT(On_SaveAndExit()));
    } else if (mode == MODE_VIEW)
    {
        ui->btnPart->hide();
        connect(ui->btnSave, SIGNAL(clicked(bool)), this, SLOT(On_SavePart()));
    }
    QShortcut *save = new QShortcut(QKeySequence("Ctrl+S"), this);
    connect(save, SIGNAL(activated()), this, SLOT(On_SavePart()));

    for (QString name : str_Operations )
    {
        OperationFrame* frame = new OperationFrame(name, this);
        frame->show();
        ui->verticalLayout_2->addWidget(frame);
        OpeFrames.append(frame);
    }

    UpdateLayout();
}

PartPage::~PartPage()
{
    delete ui;
}

void PartPage::LoadDocument(Part* p)
{
    // clean variables
    if (doc != nullptr)
    {
//        foreach (VariableLine* v, Vars) {
//            ui->gridLayout->removeWidget(v);
//            v->deleteLater();
//        }
        //delete doc;   No need to delete document
    }

    doc = p;
    UpdateData(false);

    UpdateVariableList();

    for (int i = 0; i < OpeFrames.size(); i++)
    {
        OpeFrames[i]->SetData(p->OpeData[i]);
        connect(OpeFrames[i], SIGNAL(data_changed()), doc, SLOT(on_DataChanged()));
    }
    UpdateLayout();
    emit updateTitle();
}

// Update layout and scroll size
void PartPage::UpdateLayout()
{
    int minw = 600;
    int need = 0;
    for (int row = 0; row < OpeFrames.size(); row++)
    {
        OpeFrames[row]->UpdateLayout();
        need = qMax(need, OpeFrames[row]->width());
    }
    need = qMax(minw, need);
    setMinimumWidth(need);
}

bool PartPage::UpdateData(bool save)
{
    SettingModel* sm = SettingModel::GetInstance();
    if (save)
    {
        QString oldType = doc->Type;
        QString oldFeatures = doc->Features;
        QString oldName = doc->Name;
        doc->Name = ui->editCabName->text();
        doc->Type = ui->cbPartType->currentText();
        doc->Features = ui->editFeatures->text();
        ui->btnPart->setFocus();    // Fix bug last box is not saved
        if (oldType != doc->Type || oldFeatures != doc->Features || oldName != doc->Name)
            doc->SetModifyFlag(true);
        foreach (VariableLine* vl, Vars) {
            if (vl->vm->Value != vl->GetValue())
            {
                vl->UpdateData(true);
                doc->SetModifyFlag(true);
            }
        }
    }
    else{
        ui->editCabName->setText(doc->Name);
        ui->cbPartType->setCurrentText(doc->Type);
        ui->editFeatures->setText(doc->Features);
        foreach (VariableLine* v, Vars) {
            v->UpdateData(false);
        }
    }
    return true;
}

// Load variable from setting.
void PartPage::UpdateVariableList()
{
    SettingModel* sm = SettingModel::GetInstance();

    // Save variable
    UpdateData(true);
    // Add button [New variable]
    if (btnNewVar == NULL)
    {
        btnNewVar = new QPushButton("New variable", this);
        btnNewVar->setMinimumHeight(22);
        connect(btnNewVar, SIGNAL(clicked()), this, SLOT(on_new_variable()));
    } else {
        ui->gridLayout->removeWidget(btnNewVar);
    }    

    if (ui->gridLayout->count() > 0)
    {
        foreach (VariableLine* v, Vars) {
            ui->gridLayout->removeWidget(v);
            v->deleteLater();
        }
    }
    Vars.clear();

    int i = 0;
    foreach (VarModel* vm, doc->Properties) {
        VariableLine* v = new VariableLine(this);
        v->SetModel(vm);
        Vars.append(v);
        ui->gridLayout->addWidget(v, i % MAXROW_VAR, (i / MAXROW_VAR)*COLUMN_VAR, 1, 1);

        // Disable some variable in View mode
        if ( mode == MODE_VIEW &&
                (vm->Name == CHEIGHT ||
                vm->Name == CWIDTH ||
                vm->Name == CDEPTH))
        {
            v->setEnabled(false);
            i++;
            continue;
        }

        QSignalMapper* signalMapperSubmenu = new QSignalMapper(v);
        QMenu* menu = new QMenu();
        foreach (QString str, sm->variable_list) {
            QAction* act = menu->addAction(str);
            connect(act, SIGNAL(triggered()), signalMapperSubmenu, SLOT(map()));
            signalMapperSubmenu->setMapping(act, str);
        }
        connect(signalMapperSubmenu, SIGNAL(mapped(const QString &)), SLOT(on_view_variable(const QString &)));
        v->SetMenuView(menu);

        QSignalMapper* signalMapperPart = new QSignalMapper(v);
        QMenu* menuPart = new QMenu();
        foreach (QString str, sm->GetListPartVariable()) {
            QAction* act = menuPart->addAction(str);
            connect(act, SIGNAL(triggered()), signalMapperPart, SLOT(map()));
            signalMapperPart->setMapping(act, str);
        }
        connect(signalMapperPart, SIGNAL(mapped(const QString &)), SLOT(on_sel_part_variable(const QString &)));
        v->SetMenuPart(menuPart);

        connect(v, SIGNAL(click_remove()), this, SLOT(on_remove_variable()));
        connect(v, SIGNAL(edit_value(QString)), this, SLOT(on_dataChanged()));
        i++;
    }
    ui->gridLayout->addWidget(btnNewVar, i % MAXROW_VAR, (i / MAXROW_VAR)*COLUMN_VAR, 1, 1);
}

void PartPage::UpdateSettings()
{
    int oldIdx = ui->cbPartType->currentIndex();
    QString oldText = ui->cbPartType->currentText();
    ui->cbPartType->clear();
    SettingModel* sm = SettingModel::GetInstance();
    QStringList newList = sm->GetListPartVariable();
    foreach (QString str, newList) {
        ui->cbPartType->addItem(str);
    }

    if (newList.contains(oldText))
    {
        ui->cbPartType->setCurrentIndex(newList.indexOf(oldText));
    }
    else if (ui->cbPartType->count() > oldIdx)
    {
        ui->cbPartType->setCurrentIndex(oldIdx);
    }
    else
    {
        ui->cbPartType->setCurrentIndex(-1);
    }

    ChangeVariableList();
}

void PartPage::ChangeVariableList()
{
    // Update dropdown list
    foreach (VariableLine* v, Vars) {
        QSignalMapper* signalMapperSubmenu = new QSignalMapper(v);
        QMenu* menu = new QMenu();
        foreach (QString str, SettingModel::GetInstance()->variable_list) {
            QAction* act = menu->addAction(str);
            connect(act, SIGNAL(triggered()), signalMapperSubmenu, SLOT(map()));
            signalMapperSubmenu->setMapping(act, str);
        }
        connect(signalMapperSubmenu, SIGNAL(mapped(const QString &)), SLOT(on_view_variable(const QString &)));
        v->SetMenuView(menu);

        SettingModel* sm = SettingModel::GetInstance();
        QSignalMapper* signalMapperPart = new QSignalMapper(v);
        QMenu* menuPart = new QMenu();
        foreach (QString str, sm->GetListPartVariable()) {
            QAction* act = menuPart->addAction(str);
            connect(act, SIGNAL(triggered()), signalMapperPart, SLOT(map()));
            signalMapperPart->setMapping(act, str);
        }
        connect(signalMapperPart, SIGNAL(mapped(const QString &)), SLOT(on_sel_part_variable(const QString &)));
        v->SetMenuPart(menuPart);
    }
}

// return   true: save document
//          false: cancel
bool PartPage::SaveModified()
{
    // Check change
    UpdateData(true);
    if (doc->IsModified())
    {
        QMessageBox::StandardButton reply = QMessageBox::question(NULL, "Confirm", "The part document has been modified. Do you want to save?",
                        QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        if (reply == QMessageBox::Yes)
        {
            // Save document
            doc->SaveDocument();
        } else if (reply == QMessageBox::Cancel) {
            return false;
        }
    }
    return true;
}


void PartPage::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton &&
            event->pos().y() < ui->frame->maximumHeight()) {
        QWidget* widget = QApplication::widgetAt(QCursor::pos());
        QLabel* lbl = qobject_cast<QLabel*>(widget);
        if (lbl == nullptr)
            return;
        QDrag *drag = new QDrag(this);
        QMimeData *mimeData = new QMimeData;
        mimeData->setText(lbl->text());
        drag->setMimeData(mimeData);

        Qt::DropAction dropAction = drag->exec();
    }
}

void PartPage::mouseMoveEvent(QMouseEvent *event)
{

}

//=========================================
// Part's menu
void PartPage::On_OpenPart()
{
    if (!SaveModified())
        return;     // user cancel

    // Open new part
    QString selfilter = tr("PRT (*.prt)");
    QString fileName = QFileDialog::getOpenFileName(
            this,
            "Open part",
            doc->Path,
            tr("All files (*.*);;PRT (*.prt)" ),
            &selfilter
    );
    if (fileName.length() > 0)
    {
        Part* newdoc = new Part();
        newdoc->OpenDocument(fileName);
        LoadDocument(newdoc);
    }
    else
        return;
}

void PartPage::On_SavePart()
{
    QObject* p = parent();
    QString classname = p->metaObject()->className();
    if (!doc->IsSaved() && classname != "FloatDlg")
    {
        QString selfilter = tr("PRT (*.prt)");
        QString fileName = QFileDialog::getSaveFileName(
                this,
                "Save",
                doc->Path,
                tr("All files (*.*);;PRT (*.prt)" ),
                &selfilter
        );
        if (fileName.length() > 0)
        {
            doc->Path = fileName;
        }
        else
            return;
    }
    UpdateData(true);
    doc->SaveDocument();
    emit saveDoc(doc);
}

void PartPage::On_SavePartAs()
{
    QObject* p = parent();
    QString classname = p->metaObject()->className();
    if (classname == "FloatDlg")
        return;

    QString selfilter = tr("PRT (*.prt)");
    QString newfile = GetNextFile(SettingModel::GetPartsDir() + "/part.prt");
    QString fileName = QFileDialog::getSaveFileName(
            this,
            "Save As",
            newfile,
            tr("All files (*.*);;PRT (*.prt)" ),
            &selfilter
    );
    if (fileName.length() == 0)
        return;

    // QFileInfo fileInfo(fileName);
    //ui->editCabName->setText(fileInfo.baseName());
    doc->Path = fileName;
    UpdateData(true);

    doc->SaveDocument();
}

void PartPage::On_CreateGCode()
{
    doc->SaveDocument();
    QString selfilter = tr("TXT (*.txt)");
    QString newfile = GetNextFile(SettingModel::GetPartsDir() + "/gcode.txt");
    QString fileName = QFileDialog::getSaveFileName(
            this,
            "Save G-Code",
            newfile,
            tr("All files (*.*);;TXT (*.txt)" ),
            &selfilter
    );
    if (fileName.length() == 0)
        return;
    doc->CreateGCode(fileName);
}

void PartPage::On_SaveAndExit()
{

}

void PartPage::on_mousePressLabel(QMouseEvent *event)
{

}

void PartPage::on_view_variable(const QString &var_name)
{
    QObject* o = sender();
    QSignalMapper* map = qobject_cast<QSignalMapper*>(o);
    if (map == NULL)
        return;

    // Get selected variable
    VariableLine* vl = qobject_cast<VariableLine*>(map->parent());
    if (vl == NULL)
        return;


    // Rename variable
    vl->SetName(var_name);


    // refresh
    //UpdateVariableList();
}

void PartPage::on_sel_part_variable(const QString &var_name)
{
    QObject* o = sender();
    QSignalMapper* map = qobject_cast<QSignalMapper*>(o);
    if (map == NULL)
        return;

    // Get selected variable
    VariableLine* vl = qobject_cast<VariableLine*>(map->parent());
    if (vl == NULL)
        return;


    // Rename variable
    vl->SetName(var_name);
}

void PartPage::on_remove_variable()
{
    QObject* o = sender();
    VariableLine* vl = qobject_cast<VariableLine*>(o);
    if (vl == nullptr)
        return;

    ui->gridLayout->removeWidget(vl);
    doc->Properties.removeAll(vl->vm);
    vl->deleteLater();
    UpdateVariableList();

}

void PartPage::on_new_variable()
{
    VarModel* vm = new VarModel("", "0");

    doc->Properties.append(vm);
    UpdateVariableList();
}

void PartPage::on_dataChanged()
{
    doc->SetModifyFlag(true);
}

void PartPage::on_btnViewPartType_clicked()
{
    SettingWindow settingWnd(SW_MODE_SELECT, QApplication::activeWindow());
    int ret = settingWnd.exec();
    if (ret == QDialog::Rejected)
        return;

}
