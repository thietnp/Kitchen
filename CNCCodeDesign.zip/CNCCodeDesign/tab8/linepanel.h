#ifndef FORMDATA_H
#define FORMDATA_H

#include <QGroupBox>
#include <QList>
#include <basebox.h>
#include "linedata.h"

namespace Ui {
class LinePanel;
}

class LinePanel : public QGroupBox
{
    Q_OBJECT

public:
    explicit LinePanel(QWidget *parent = 0);
    ~LinePanel();
    QList<BaseBox*> Items;
private:
    Ui::LinePanel *ui;
    LineData* lData;

public:
    // public methods
    LineData* GetData() { return lData;}
    void SetData(LineData* data);
    void InsertBox(BaseBox* box, int idx = -1);
    void UpdateLayout();

signals:
    void data_changed();

private slots:
    // Button clicked
    void on_btnAddText_clicked();
    void on_btnAddNum_clicked();

    // Actions of the Line
    void on_NewLineAbove();
    void on_NewLineBellow();
    void on_CopyLine();
    void on_MoveLineUp();
    void on_MoveLineDown();
    void on_DeleteLine();

    // Actions of the Box
    void on_TextBefore();
    void on_TextAfter();
    void on_NumBefore();
    void on_NumAfter();
    void on_CopyContent();
    void on_PasteContent();
    void on_DeleteBox();

    void on_textChanged();

protected:
    //bool event( QEvent *evt ) override;
};

#endif // FORMDATA_H
