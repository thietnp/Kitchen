#ifndef PAGEHOME_H
#define PAGEHOME_H

#include <QWidget>
#include <QList>
#include <QPushButton>
#include <QSignalMapper>
#include "basebox.h"
#include "operationframe.h"
#include "part.h"
#include "basepage.h"

namespace Ui {
class PartPage;
}

class PartPage : public BasePage
{
    Q_OBJECT

public:

    explicit PartPage(Mode _mode, QWidget *parent = 0);
    ~PartPage();
    QList<OperationFrame*> OpeFrames;
    QList<VariableLine*> Vars;
    int SelRow;

private:
    Ui::PartPage *ui;
    QPushButton* btnNewVar;
    QList<QWidget*> var_list;
    Part* doc;     // Part data
    //QSignalMapper* signalMapperRm;

    // Public methods
public:
    Part* GetDocument() {return doc;}
    void LoadDocument(Part* p);
    void UpdateLayout();
    bool UpdateData(bool save) override;
    void UpdateVariableList();
    void UpdateSettings() override;
    void ChangeVariableList();
    bool SaveModified();

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;

signals:
    void saveDoc(Document*);

private slots:
    // Part's menu
    void On_OpenPart();
    void On_SavePart();
    void On_SavePartAs();
    void On_CreateGCode();
    void On_SaveAndExit();

    // Drag label
    void on_mousePressLabel(QMouseEvent *event);

    // Show view variabel name
    void on_view_variable(const QString &var_name);
    void on_sel_part_variable(const QString &var_name);
    void on_remove_variable();

    void on_new_variable();
    void on_dataChanged();
    void on_btnViewPartType_clicked();
};

class ParamMenu
{
public:
    ParamMenu() {}
    VariableLine* var;
    QString curText;    // Current text
};

#endif // PAGEHOME_H
