#ifndef PARTFORM_H
#define PARTFORM_H

#include <QFrame>
#include "part.h"

namespace Ui {
class PartForm;
}

class PartForm : public QFrame
{
    Q_OBJECT

public:
    explicit PartForm(QWidget *parent = 0);
    ~PartForm();
    inline Part* getPart() { return p;}
    void setPart(Part* _p);
    bool UpdateData(bool save);

signals:
    void viewPart();
    void removePart();
private slots:
    void on_btnView_clicked();
    void on_btnRemove_clicked();
    void on_changed();
    void on_DocChanged(Document* newdoc, Document* doc_org);

private:
    Ui::PartForm *ui;
    Part* p;
};

#endif // PARTFORM_H
