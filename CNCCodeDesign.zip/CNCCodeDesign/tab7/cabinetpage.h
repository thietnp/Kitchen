#ifndef CABINETPAGE_H
#define CABINETPAGE_H

#include <QWidget>
#include "cabinet.h"
#include "partform.h"
#include "basepage.h"

namespace Ui {
class CabinetPage;
}

class CabinetPage : public BasePage
{
    Q_OBJECT

public:
    explicit CabinetPage(Mode _mode, QWidget *parent = 0);
    ~CabinetPage();
    Cabinet* GetDocument() { return doc;}
    void LoadDocument(Cabinet* cab);
    void AddPartPanel(PartForm* panel);
    void UpdateSettings() override;
    bool UpdateData(bool save) override;
    void UpdateLayout();
    bool SaveModified();
signals:
    void saveDoc(Document*);
private:
    Ui::CabinetPage *ui;
    Cabinet* doc;
    QList<PartForm*> forms;

private slots:
    // Cabinet menu
    void on_OpenCabinet();
    void on_SaveCabinet();
    void on_SaveCabinetAs();
    void on_CreateGCode();
    void on_SaveAndExit();

    void updateDimensions();

    // View part page
    void on_viewPart();
    void on_removePart();
    void on_btnAddPart_clicked();
};

#endif // CABINETPAGE_H
