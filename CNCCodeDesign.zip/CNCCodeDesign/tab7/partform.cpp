#include "partform.h"
#include "ui_partform.h"
#include "settingmodel.h"
#include "cabinet.h"

PartForm::PartForm(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::PartForm)
{
    ui->setupUi(this);
    p = nullptr;
    // TODO:
    //    foreach (QString type, SettingModel::GetInstance()->part_types) {
//        ui->cbPartType->addItem(type);
//    }

    connect(ui->cbPartType, SIGNAL(currentTextChanged(QString)), this, SLOT(on_changed()));
    connect(ui->editPartName, SIGNAL(textChanged(QString)), this, SLOT(on_changed()));
    connect(ui->editFeatures, SIGNAL(textChanged(QString)), this, SLOT(on_changed()));
}

PartForm::~PartForm()
{
    delete ui;
}

void PartForm::setPart(Part* _p)
{
    p = _p;
    UpdateData(false);
}

// return   true: document has modified
//          false: document not change
bool PartForm::UpdateData(bool save)
{
    if (save)
    {
        QString oldname = p->Name;
        QString oldtype = p->Type;
        QString oldfeature = p->Features;
        p->Name = ui->editPartName->text();
        p->Type = ui->cbPartType->currentText();
        p->Features = ui->editFeatures->text();
        if (oldname != p->Name ||
                oldtype != p->Type ||
                oldfeature != p->Features)
            return true;
    } else {
        //int idx = SettingModel::GetInstance()->part_types.indexOf(p->Type);
        //ui->cbPartType->setCurrentIndex(idx);
        ui->cbPartType->setCurrentText(p->Type);
        ui->editPartName->setText(p->Name);
        ui->editFeatures->setText(p->Features);
    }
    return false;
}

void PartForm::on_btnRemove_clicked()
{
    emit removePart();
}

void PartForm::on_btnView_clicked()
{
    UpdateData(true);
    emit viewPart();
}

void PartForm::on_changed()
{
    p->SetModifyFlag(true);
}

// Receive notification from floating dialog
void PartForm::on_DocChanged(Document* newdoc, Document* doc_org)
{
    Part* old = p;
    Cabinet* cab = qobject_cast<Cabinet*>(old->parent());
    Part* newpart = qobject_cast<Part*>(newdoc);

    // Replace part
    if (cab != nullptr)
    {
        int idx = cab->Parts.indexOf(old);
        if (idx < 0)
        {
            QMessageBox::critical(this, "Unknown error", "Cannot update cabinet", QMessageBox::Ok);
            return;
        }
        cab->Parts.replace(idx, newpart);
        cab->SetModifyFlag(true);
    }

    // Update ui
    setPart(newpart);
    //delete old;   avoid bug
}
