#include <QMenu>
#include "cabinetpage.h"
#include "ui_cabinetpage.h"
#include "partform.h"
#include "utils.h"
#include "settingmodel.h"
#include "mainwindow.h"
#include <QShortcut>
#include "floatdlg.h"

CabinetPage::CabinetPage(Mode _mode, QWidget *parent) :
    BasePage(parent),
    ui(new Ui::CabinetPage)
{
    mode = _mode;
    ui->setupUi(this);
    SetWidgetStyle(ui->btnAddPart, "red_button.qss");
    doc = nullptr;

    foreach (QString type, SettingModel::GetInstance()->cabinet_types) {
        QIcon icon(":/res/cab1.png");
        ui->cbCabType->addItem(icon, type);
    }

    connect(ui->editCabHeight, SIGNAL(editingFinished()), this, SLOT(updateDimensions()));
    connect(ui->editCabDepth, SIGNAL(editingFinished()), this, SLOT(updateDimensions()));
    connect(ui->editCabWidth, SIGNAL(editingFinished()), this, SLOT(updateDimensions()));

    if (mode == MODE_EDIT)
    {
        ui->btnSave->hide();
        QMenu* pmenu = new QMenu();
        pmenu->addAction(tr("Open Cabinet"), this, SLOT(on_OpenCabinet()));
        pmenu->addAction(tr("Save Cabinet"), this, SLOT(on_SaveCabinet()));
        pmenu->addAction(tr("Save Cabinet As"), this, SLOT(on_SaveCabinetAs()));
        pmenu->addAction(tr("Create G-Code"), this, SLOT(on_CreateGCode()));
        pmenu->addAction(tr("Save And Exit"), this, SLOT(on_SaveAndExit()));
        ui->btnCabinet->setMenu(pmenu);

        QShortcut *open = new QShortcut(QKeySequence("Ctrl+O"), this);
        connect(open, SIGNAL(activated()), this, SLOT(on_OpenCabinet()));
        QShortcut *saveas = new QShortcut(QKeySequence("Ctrl+Alt+S"), this);
        connect(saveas, SIGNAL(activated()), this, SLOT(on_SaveCabinetAs()));
        QShortcut *gcode = new QShortcut(QKeySequence("Ctrl+G"), this);
        connect(gcode, SIGNAL(activated()), this, SLOT(on_CreateGCode()));
        QShortcut *savequit = new QShortcut(QKeySequence("Ctrl+Q"), this);
        connect(savequit, SIGNAL(activated()), this, SLOT(on_SaveAndExit()));
    } else if (mode == MODE_VIEW)
    {
        ui->btnCabinet->hide();
        connect(ui->btnSave, SIGNAL(clicked(bool)), this, SLOT(on_SaveCabinet()));
    }

    QShortcut *save = new QShortcut(QKeySequence("Ctrl+S"), this);
    connect(save, SIGNAL(activated()), this, SLOT(on_SaveCabinet()));
}

CabinetPage::~CabinetPage()
{
    delete ui;
}

void CabinetPage::LoadDocument(Cabinet* cab)
{
    if (doc != NULL)
        delete doc;
    doc = cab;
    foreach (QWidget* w, forms) {
        ui->verticalLayout_3->removeWidget(w);
        delete w;
    }
    forms.clear();
    UpdateData(false);

    foreach (Part* p, doc->Parts) {
        PartForm* form = new PartForm(ui->scrollAreaWidgetContents);
        AddPartPanel(form);
        form->setPart(p);
    }
    emit updateTitle();
}

void CabinetPage::AddPartPanel(PartForm* panel)
{
    forms.append(panel);
    ui->verticalLayout_3->addWidget(panel);
    connect(panel, SIGNAL(viewPart()), this, SLOT(on_viewPart()));
    connect(panel, SIGNAL(removePart()), this, SLOT(on_removePart()));
}

void CabinetPage::UpdateSettings()
{
    int oldIdx = ui->cbCabType->currentIndex();
    QString oldText = ui->cbCabType->currentText();
    ui->cbCabType->clear();
    SettingModel* sm = SettingModel::GetInstance();
    foreach (QString type, sm->cabinet_types) {
        ui->cbCabType->addItem(type);
    }

    ui->cbCabType->setCurrentText(doc->Type);
//    if (sm->part_types.contains(oldText))
//    {
//        ui->cbCabType->setCurrentIndex(sm->part_types.indexOf(oldText));
//    }
//    else if (ui->cbCabType->count() > oldIdx)
//    {
//        ui->cbCabType->setCurrentIndex(oldIdx);
//    }
//    else
//    {
//        ui->cbCabType->setCurrentIndex(-1);
//    }
}

bool CabinetPage::UpdateData(bool save)
{
    if (save)
    {
        QString oldname = doc->Name;
        QString oldtype = doc->Type;
        QString oldfeature = doc->Features;
        QString oldheight = doc->Height;
        QString olddepth = doc->Depth;
        QString oldwidth = doc->Width;
        doc->Name = ui->editCabName->text();
        doc->Type = ui->cbCabType->currentText();
        doc->Features = ui->editCabFeatures->text();
        doc->Height = ui->editCabHeight->text();
        doc->Depth = ui->editCabDepth->text();
        doc->Width = ui->editCabWidth->text();
        if (oldname != doc->Name ||
                oldtype != doc->Type||
                oldfeature != doc->Features ||
                oldheight != doc->Height ||
                olddepth != doc->Depth ||
                oldwidth != doc->Width)
            doc->SetModifyFlag(true);

        foreach (PartForm* pf, forms) {
            if (pf->UpdateData(true))
                doc->SetModifyFlag(true);
        }
    } else {
        ui->editCabName->setText(doc->Name);
        ui->cbCabType->setCurrentText(doc->Type);
        ui->editCabFeatures->setText(doc->Features);
        ui->editCabHeight->setText(doc->Height);
        ui->editCabDepth->setText(doc->Depth);
        ui->editCabWidth->setText(doc->Width);
    }
    return true;
}

void CabinetPage::updateDimensions()
{
    doc->Height = ui->editCabHeight->text();
    doc->Depth = ui->editCabDepth->text();
    doc->Width = ui->editCabWidth->text();
    foreach (PartForm* pf, forms) {
        pf->getPart()->SetVariable(CHEIGHT, doc->Height);
        pf->getPart()->SetVariable(CDEPTH, doc->Depth);
        pf->getPart()->SetVariable(CWIDTH, doc->Width);
    }
    doc->SetModifyFlag(true);
}

void CabinetPage::UpdateLayout()
{

}

// return   true: save document
//          false: cancel
bool CabinetPage::SaveModified()
{
    // Check change
    UpdateData(true);
    if (doc->IsModified())
    {
        QMessageBox::StandardButton reply = QMessageBox::question(NULL, "Confirm", "The cabinet document has been modified. Do you want to save?",
                        QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        if (reply == QMessageBox::Yes)
        {
            // Save document
            doc->SaveDocument();
        } else if (reply == QMessageBox::Cancel) {
            return false;
        }
    }
    return true;
}

void CabinetPage::on_OpenCabinet()
{
    if (!SaveModified())
        return;     // user cancel

    // Open new part
    QString selfilter = tr("CBN (*.cbn)");
    QString fileName = QFileDialog::getOpenFileName(
            this,
            "Open cabinet",
            doc->Path,
            tr("All files (*.*);;CBN (*.cbn)" ),
            &selfilter
    );
    if (fileName.length() > 0)
    {
        Cabinet* newcab = new Cabinet();
        newcab->OpenDocument(fileName);
        LoadDocument(newcab);
    }
    else
        return;
}

void CabinetPage::on_SaveCabinet()
{
    QObject* p = parent();
    QString classname = p->metaObject()->className();
    bool saved = doc->IsSaved();
    if (!doc->IsSaved() && classname != "FloatDlg")
    {
        QString selfilter = tr("CBN (*.cbn)");

        QString fileName = QFileDialog::getSaveFileName(
                this,
                "Save Cabinet",
                doc->Path,
                tr("All files (*.*);;CBN (*.cbn)" ),
                &selfilter
        );
        if (fileName.length() > 0)
        {
            doc->Path = fileName;
        }
        else
            return;
    }

    UpdateData(true);
    doc->SaveDocument();
    if (classname != "FloatDlg")
    {
        if (!saved)
            QMessageBox::information(QApplication::activeWindow(), "Saved", "The cabinet is created", QMessageBox::Ok);
    }
    emit saveDoc(doc);
}

void CabinetPage::on_SaveCabinetAs()
{
    QObject* p = parent();
    QString classname = p->metaObject()->className();
    if (classname == "FloatDlg")
        return;

    QString selfilter = tr("CBN (*.cbn)");
    QString newfile = GetNextFile(SettingModel::GetCabinetsDir() + "/cabinet.cbn");

    qDebug() << doc->Path;
    QString fileName = QFileDialog::getSaveFileName(
                this,
                "Save Cabinet As",
                newfile,
                tr("All files (*.*);;CBN (*.cbn)" ),
                &selfilter
                );
    if (fileName.length() > 0)
    {
        doc->Path = fileName;
    } else
        return;

    UpdateData(true);
    doc->SaveDocument();
    QMessageBox::information(QApplication::activeWindow(), "Saved", "The cabinet is created", QMessageBox::Ok);
}

void CabinetPage::on_CreateGCode()
{
    doc->SaveDocument();
    QString selfilter = tr("TXT (*.txt)");
    QString newfile = GetNextFile(SettingModel::GetCabinetsDir() + "/gcode.txt");
    QString fileName = QFileDialog::getSaveFileName(
            this,
            "Save G-Code",
            newfile,
            tr("All files (*.*);;TXT (*.txt)" ),
            &selfilter
    );
    if (fileName.length() == 0)
        return;
    doc->CreateGCode(fileName);
}

void CabinetPage::on_SaveAndExit()
{

}

void CabinetPage::on_removePart()
{
    QObject* o = sender();
    PartForm* form = qobject_cast<PartForm*>(o);
    if (form == nullptr)
        return;

    forms.removeAll(form);
    doc->Parts.removeAll(form->getPart());
    ui->verticalLayout_3->removeWidget(form);
    form->deleteLater();
}

void CabinetPage::on_viewPart()
{
    UpdateData(true);
    QWidget* parentWnd = MainWindow::g_mainWindow;
    QObject* o = sender();
    PartForm* form = qobject_cast<PartForm*>(o);
    if (form == nullptr)
        return;

    Part* p =form->getPart();
    if (p == nullptr)
        return;

    Part* clone = qobject_cast<Part*>(p->Clone());

    FloatDlg* flDlg = new FloatDlg(parentWnd);

    flDlg->SetDocument(clone, p);
    SetWidgetStyle(flDlg, "label_style1.qss");
    connect(flDlg, SIGNAL(docChanged(Document*, Document*)), form, SLOT(on_DocChanged(Document*, Document*)));
    flDlg->show();
}

void CabinetPage::on_btnAddPart_clicked()
{
    UpdateData(true);
    QString selfilter = tr("PRT (*.prt)");
    QString fileName = QFileDialog::getOpenFileName(
            this,
            "Add Part",
            SettingModel::ProjectDir + "/parts",
            tr("All files (*.*);;PRT (*.prt)" ),
            &selfilter
    );
    if (fileName.length() > 0)
    {
        Part* p = new Part(this);
        bool ret = p->OpenDocument(fileName);
        if (ret)
        {
            // Override dementions
            p->SetVariable(CHEIGHT, doc->Height);
            p->SetVariable(CDEPTH, doc->Depth);
            p->SetVariable(CWIDTH, doc->Width);

           doc->Parts.append(p);
           PartForm* form = new PartForm(ui->scrollAreaWidgetContents);
           AddPartPanel(form);
           form->setPart(p);
           doc->SetModifyFlag(true);
        }
        else
        {
            delete p;
        }
    }
}
